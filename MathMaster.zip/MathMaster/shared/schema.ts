import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User stats table
export const userStats = pgTable("user_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  gamesPlayed: integer("games_played").default(0).notNull(),
  correctAnswers: integer("correct_answers").default(0).notNull(),
  incorrectAnswers: integer("incorrect_answers").default(0).notNull(),
  totalTime: integer("total_time").default(0).notNull(), // stored in milliseconds
  highScore: integer("high_score").default(0).notNull(),
  lastPlayed: timestamp("last_played").defaultNow().notNull(),
});

// User streaks table
export const userStreaks = pgTable("user_streaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  currentStreak: integer("current_streak").default(0).notNull(),
  bestStreak: integer("best_streak").default(0).notNull(),
  lastCompletedDate: date("last_completed_date"),
});

// User completed days table (for streak calendar)
export const completedDays = pgTable("completed_days", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: date("date").notNull(),
});

// Challenges table
export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // e.g., "cross_math", "div3", "open"
  title: text("title").notNull(),
  description: text("description").notNull(),
  dateCreated: date("date_created").defaultNow().notNull(),
  puzzleData: text("puzzle_data").notNull(), // JSON string of puzzle data
  solution: text("solution").notNull(), // JSON string of solution
});

// User challenge completions
export const challengeCompletions = pgTable("challenge_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  challengeId: integer("challenge_id").notNull().references(() => challenges.id),
  dateCompleted: timestamp("date_completed").defaultNow().notNull(),
  isCorrect: boolean("is_correct").notNull(),
  timeSpent: integer("time_spent").notNull(), // in milliseconds
});

// Zod schemas for input validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertUserStatsSchema = createInsertSchema(userStats).pick({
  userId: true,
  gamesPlayed: true,
  correctAnswers: true,
  incorrectAnswers: true,
  totalTime: true,
  highScore: true,
});

export const insertUserStreakSchema = createInsertSchema(userStreaks).pick({
  userId: true,
  currentStreak: true,
  bestStreak: true,
  lastCompletedDate: true,
});

export const insertChallengeCompletionSchema = createInsertSchema(challengeCompletions).pick({
  userId: true,
  challengeId: true,
  isCorrect: true,
  timeSpent: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertUserStats = z.infer<typeof insertUserStatsSchema>;
export type UserStats = typeof userStats.$inferSelect;

export type InsertUserStreak = z.infer<typeof insertUserStreakSchema>;
export type UserStreak = typeof userStreaks.$inferSelect;

export type InsertChallengeCompletion = z.infer<typeof insertChallengeCompletionSchema>;
export type ChallengeCompletion = typeof challengeCompletions.$inferSelect;
