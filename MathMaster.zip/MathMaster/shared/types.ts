// Game-related types 
export type MathProblemType = "addition" | "subtraction" | "multiplication" | "division" | "mixed";
export type DifficultyLevel = "easy" | "medium" | "hard" | "expert";

export interface MathProblem {
  expression: string;
  answer: number;
  type: MathProblemType;
  difficulty: DifficultyLevel;
}

export interface MathProblemSet {
  problems: MathProblem[];
  timeLimit?: number; // in seconds, optional
  totalPoints: number;
}

// User profile types
export interface UserProfile {
  id: number;
  username: string;
  joinDate: string;
  avatarUrl?: string;
  stats: UserProfileStats;
  badges: Badge[];
  recentGames: RecentGame[];
}

export interface UserProfileStats {
  gamesPlayed: number;
  correctAnswers: number;
  totalQuestions: number;
  highestStreak: number;
  averageSpeed: number; // in seconds
  highScore: number;
}

export interface Badge {
  id: number;
  name: string;
  description: string;
  earnedDate?: string;
  icon?: string;
}

export interface RecentGame {
  id: number;
  type: string;
  date: string;
  score: number;
  result: "win" | "lose" | "draw";
}

// Streak and challenge types
export interface StreakData {
  currentStreak: number;
  bestStreak: number;
  lastCompletedDate: string | null;
  daysCompleted: string[]; // ISO format dates
}

export interface DailyChallenge {
  id: string;
  type: string;
  date: string;
  description: string;
  puzzle: ChallengePuzzle;
  solution: any; // This could be an array, number, or string depending on puzzle type
}

export type ChallengePuzzle = 
  | GridPuzzle
  | Div3Puzzle
  | OpenPuzzle;

export interface GridPuzzle {
  type: "grid";
  size: number;
  targetSum: number;
  cells: (number | null)[][];
}

export interface Div3Puzzle {
  type: "div3";
  grid: number[][];
}

export interface OpenPuzzle {
  type: "open";
  question: string;
}

// Leaderboard types
export interface LeaderboardEntry {
  rank: number;
  userId: number;
  username: string;
  score: number;
  avatarUrl?: string;
}

export interface Leaderboard {
  type: "global" | "weekly" | "friends";
  entries: LeaderboardEntry[];
}

// Game state types for multiplayer
export type GamePhase = "ready" | "playing" | "ended";

export interface GameState {
  phase: GamePhase;
  players: Player[];
  currentRound: number;
  totalRounds: number;
  timeLeft: number;
}

export interface Player {
  userId: number;
  username: string;
  score: number;
  currentAnswer?: string;
  isCorrect?: boolean;
  answerTime?: number; // in milliseconds
}

// WebSocket message types
export type WebSocketMessageType = 
  | "join_duel" 
  | "duel_status" 
  | "start_game"
  | "problem" 
  | "submit_answer" 
  | "answer_result"
  | "game_update"
  | "game_end"
  | "error";

export interface WebSocketMessage {
  type: WebSocketMessageType;
  [key: string]: any; // Additional properties based on message type
}
