import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import MemoryStore from "memorystore";
import { WebSocketServer } from "ws";

// Import controllers
import * as authController from "./controllers/authController";
import * as statsController from "./controllers/statsController";
import * as problemController from "./controllers/problemController";

// Create session store
const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "matiks-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: { 
        secure: process.env.NODE_ENV === "production",
        maxAge: 86400000 // 1 day
      },
      store: new SessionStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
    })
  );

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Auth routes
  app.post("/api/auth/register", authController.register);
  app.post("/api/auth/login", authController.login);
  app.post("/api/auth/logout", authController.logout);
  app.get("/api/auth/me", authController.getCurrentUser);

  // User stats routes
  app.get("/api/stats", requireAuth, statsController.getUserStats);
  app.post("/api/stats/increment-game", requireAuth, statsController.incrementGamePlayed);
  app.post("/api/stats/add-result", requireAuth, statsController.addResult);
  app.post("/api/stats/reset", requireAuth, statsController.resetStats);

  // Streak and challenge routes
  app.get("/api/streak", requireAuth, problemController.getUserStreak);
  app.post("/api/streak/update", requireAuth, problemController.updateStreak);
  app.post("/api/streak/reset", requireAuth, problemController.resetStreak);
  app.get("/api/daily-challenges", problemController.getDailyChallenges);
  app.get("/api/daily-challenge/:id", problemController.getDailyChallenge);

  // Leaderboard routes
  app.get("/api/leaderboard/:type", statsController.getLeaderboard);

  // Sample user data for demo purposes
  await setupSampleData();

  // Create HTTP server
  const httpServer = createServer(app);

  // Set up WebSocket server for real-time multiplayer with a specific path
  // to avoid conflicts with Vite's WebSocket
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: "/ws/game",
    clientTracking: true,
    perMessageDeflate: false
  });
  
  // Track waiting players and active games
  const waitingPlayers: Map<string, any> = new Map();
  const activeGames: Map<string, {
    players: { id: string, ws: any, username: string, score: number }[],
    currentRound: number,
    totalRounds: number,
    timeRemaining: number,
    gameId: string
  }> = new Map();

  // Generate a unique game ID
  const generateGameId = () => {
    return Math.random().toString(36).substring(2, 15);
  };

  // Generate a unique player ID
  const generatePlayerId = () => {
    return Math.random().toString(36).substring(2, 15);
  };

  // Match players for a duel
  const matchPlayers = () => {
    // Check if we have at least 2 waiting players
    if (waitingPlayers.size >= 2) {
      // Get two players from the waiting list
      const players = Array.from(waitingPlayers.entries()).slice(0, 2);
      const gameId = generateGameId();
      
      // Create a new game
      const newGame = {
        players: players.map(([id, data]) => ({
          id,
          ws: data.ws,
          username: data.username || `Player_${id.substring(0, 5)}`,
          score: 0
        })),
        currentRound: 0,
        totalRounds: 10,
        timeRemaining: 60,
        gameId
      };
      
      // Store the game in active games
      activeGames.set(gameId, newGame);
      
      // Remove the players from waiting list
      players.forEach(([id]) => waitingPlayers.delete(id));
      
      // Notify both players that a match is found
      newGame.players.forEach((player, index) => {
        const opponent = newGame.players[1 - index];
        player.ws.send(JSON.stringify({
          type: "duel_status",
          status: "opponent_found",
          gameId,
          opponent: {
            username: opponent.username,
            score: 0
          }
        }));
      });
      
      console.log(`New game created: ${gameId} with players: ${newGame.players.map(p => p.username).join(", ")}`);
      
      // Start the game after a short delay
      setTimeout(() => {
        startGame(gameId);
      }, 2000);
    }
  };

  // Start a game with the given ID
  const startGame = (gameId: string) => {
    const game = activeGames.get(gameId);
    if (!game) return;
    
    game.players.forEach(player => {
      player.ws.send(JSON.stringify({
        type: "start_game",
        gameId,
        timeRemaining: game.timeRemaining,
        currentRound: game.currentRound,
        totalRounds: game.totalRounds
      }));
    });
  };

  // Update all players in a game with the current state
  const updateGameState = (gameId: string) => {
    const game = activeGames.get(gameId);
    if (!game) return;
    
    game.players.forEach(player => {
      player.ws.send(JSON.stringify({
        type: "game_update",
        gameId,
        players: game.players.map(p => ({
          username: p.username,
          score: p.score
        })),
        timeRemaining: game.timeRemaining,
        currentRound: game.currentRound,
        totalRounds: game.totalRounds
      }));
    });
  };

  wss.on("connection", (ws) => {
    console.log("WebSocket client connected");
    
    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
      // Attempt to send error to client if connection is still open
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({
          type: "error",
          message: "Connection error occurred"
        }));
      }
    });

    // Add ping/pong to keep connection alive
    const pingInterval = setInterval(() => {
      if (ws.readyState === ws.OPEN) {
        ws.ping();
      }
    }, 30000);

    ws.on("close", () => {
      clearInterval(pingInterval);
    });
    // Generate a unique player ID for this connection
    const playerId = generatePlayerId();
    
    // Handle messages from clients
    ws.on("message", (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        switch (data.type) {
          case "join_duel":
            // Add player to waiting list
            waitingPlayers.set(playerId, {
              ws,
              username: data.username || `Player_${playerId.substring(0, 5)}`,
              joinedAt: Date.now()
            });
            
            // Notify player they're waiting for an opponent
            ws.send(JSON.stringify({
              type: "duel_status",
              status: "waiting_for_opponent"
            }));
            
            console.log(`Player ${playerId} joined duel queue. Waiting players: ${waitingPlayers.size}`);
            
            // Try to match players
            matchPlayers();
            break;
            
          case "submit_answer":
            // Find the player's active game
            let playerGame = null;
            let playerInGame = null;
            
            // Use Array.from to avoid TypeScript issues with Map iteration
            Array.from(activeGames.entries()).forEach(([gameId, game]) => {
              const player = game.players.find((p: any) => p.id === playerId);
              if (player) {
                playerGame = game;
                playerInGame = player;
              }
            });
            
            if (playerGame && playerInGame) {
              // Need to assert the type to avoid TypeScript errors
              const game = playerGame as {
                players: { id: string; ws: any; username: string; score: number; }[];
                currentRound: number;
                totalRounds: number;
                timeRemaining: number;
                gameId: string;
              };
              
              const player = playerInGame as {
                id: string;
                ws: any;
                username: string;
                score: number;
              };
              
              // Update player's score
              player.score = data.score || player.score;
              
              // Send answer result to the player
              ws.send(JSON.stringify({
                type: "answer_result",
                correct: true, // In a real app, validate the answer
                score: player.score
              }));
              
              // Update all players with the new game state
              updateGameState(game.gameId);
            }
            break;
            
          default:
            console.log(`Unhandled message type: ${data.type}`);
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    });

    // Handle disconnect
    ws.on("close", () => {
      console.log(`WebSocket client disconnected: ${playerId}`);
      
      // Remove from waiting players if present
      if (waitingPlayers.has(playerId)) {
        waitingPlayers.delete(playerId);
        console.log(`Removed ${playerId} from waiting list`);
      }
      
      // Check if player is in an active game
      Array.from(activeGames.entries()).forEach(([gameId, game]) => {
        const playerIndex = game.players.findIndex((p: any) => p.id === playerId);
        
        if (playerIndex !== -1) {
          // Notify other players that this player has disconnected
          game.players.forEach((player: any, index: number) => {
            if (index !== playerIndex && player.ws.readyState === 1) { // WebSocket.OPEN
              player.ws.send(JSON.stringify({
                type: "game_end",
                reason: "opponent_disconnected"
              }));
            }
          });
          
          // Remove the game
          activeGames.delete(gameId);
          console.log(`Game ${gameId} ended due to player disconnect`);
        }
      });
    });
  });

  return httpServer;
}

// Setup sample data for demo purposes
async function setupSampleData() {
  try {
    // Check if we already have sample users
    const existingUser = await storage.getUserByUsername("amanchaudhary");
    
    if (!existingUser) {
      // Create a demo user
      await storage.createUser({
        username: "amanchaudhary",
        password: "password123"
      });
      
      // Create more demo users for leaderboard
      const demoUsers = [
        "mathgenius", "numberwizard", "calculatorkiller", 
        "speedymath", "algebrazorro", "mathlete99",
        "numbercrafter", "arithmeticace", "mathninja"
      ];
      
      for (const username of demoUsers) {
        await storage.createUser({
          username,
          password: "password123"
        });
      }
    }
  } catch (error) {
    console.error("Error setting up sample data:", error);
  }
}
