import { Request, Response } from "express";
import { z } from "zod";

// In-memory storage for user stats (would be replaced by database in production)
const userStats = new Map<number, UserStats>();

interface UserStats {
  userId: number;
  gamesPlayed: number;
  correctAnswers: number;
  incorrectAnswers: number;
  totalTime: number;
  highScore: number;
  lastPlayed: string;
}

// Validation schemas
const resultSchema = z.object({
  correct: z.boolean(),
  time: z.number().positive(),
  score: z.number().nonnegative()
});

export async function getUserStats(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.session.userId;
    
    // Get or create user stats
    let stats = userStats.get(userId);
    if (!stats) {
      stats = {
        userId,
        gamesPlayed: 0,
        correctAnswers: 0,
        incorrectAnswers: 0,
        totalTime: 0,
        highScore: 0,
        lastPlayed: new Date().toISOString()
      };
      userStats.set(userId, stats);
    }
    
    // Calculate average time
    const totalAnswers = stats.correctAnswers + stats.incorrectAnswers;
    const averageTime = totalAnswers > 0 ? stats.totalTime / totalAnswers : 0;
    
    return res.status(200).json({
      gamesPlayed: stats.gamesPlayed,
      correctAnswers: stats.correctAnswers,
      incorrectAnswers: stats.incorrectAnswers,
      averageTime,
      highScore: stats.highScore,
      lastPlayed: stats.lastPlayed
    });
  } catch (error) {
    console.error("Get stats error:", error);
    return res.status(500).json({ message: "Error getting stats" });
  }
}

export async function incrementGamePlayed(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.session.userId;
    
    // Get or create user stats
    let stats = userStats.get(userId);
    if (!stats) {
      stats = {
        userId,
        gamesPlayed: 0,
        correctAnswers: 0,
        incorrectAnswers: 0,
        totalTime: 0,
        highScore: 0,
        lastPlayed: new Date().toISOString()
      };
    }
    
    // Increment games played
    stats.gamesPlayed += 1;
    stats.lastPlayed = new Date().toISOString();
    
    // Update stats
    userStats.set(userId, stats);
    
    return res.status(200).json({ message: "Stats updated" });
  } catch (error) {
    console.error("Increment game error:", error);
    return res.status(500).json({ message: "Error updating stats" });
  }
}

export async function addResult(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Validate input
    const validatedData = resultSchema.parse(req.body);
    const userId = req.session.userId;
    
    // Get or create user stats
    let stats = userStats.get(userId);
    if (!stats) {
      stats = {
        userId,
        gamesPlayed: 0,
        correctAnswers: 0,
        incorrectAnswers: 0,
        totalTime: 0,
        highScore: 0,
        lastPlayed: new Date().toISOString()
      };
    }
    
    // Update stats
    if (validatedData.correct) {
      stats.correctAnswers += 1;
    } else {
      stats.incorrectAnswers += 1;
    }
    
    stats.totalTime += validatedData.time;
    stats.highScore = Math.max(stats.highScore, validatedData.score);
    stats.lastPlayed = new Date().toISOString();
    
    // Save updated stats
    userStats.set(userId, stats);
    
    return res.status(200).json({ message: "Result added" });
  } catch (error) {
    console.error("Add result error:", error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    return res.status(500).json({ message: "Error adding result" });
  }
}

export async function resetStats(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.session.userId;
    
    // Reset stats
    const stats = {
      userId,
      gamesPlayed: 0,
      correctAnswers: 0,
      incorrectAnswers: 0,
      totalTime: 0,
      highScore: 0,
      lastPlayed: new Date().toISOString()
    };
    
    userStats.set(userId, stats);
    
    return res.status(200).json({ message: "Stats reset" });
  } catch (error) {
    console.error("Reset stats error:", error);
    return res.status(500).json({ message: "Error resetting stats" });
  }
}

// Get leaderboard
export async function getLeaderboard(req: Request, res: Response) {
  try {
    const type = req.params.type || "global";
    
    // Convert stats map to array
    const statsArray = Array.from(userStats.values());
    
    // Sort by score
    const sortedStats = statsArray.sort((a, b) => b.highScore - a.highScore);
    
    // Map to leaderboard format
    const leaderboard = sortedStats.map((stats, index) => ({
      rank: index + 1,
      userId: stats.userId,
      username: `User${stats.userId}`, // In real app, fetch usernames
      score: stats.highScore,
    }));
    
    return res.status(200).json({ users: leaderboard });
  } catch (error) {
    console.error("Leaderboard error:", error);
    return res.status(500).json({ message: "Error getting leaderboard" });
  }
}
