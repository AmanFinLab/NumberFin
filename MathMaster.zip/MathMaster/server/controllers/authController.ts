import { Request, Response } from "express";
import { storage } from "../storage";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

// Simple login validation schema
const loginSchema = z.object({
  username: z.string().min(3).max(20),
  password: z.string().min(6),
});

export async function register(req: Request, res: Response) {
  try {
    // Validate input
    const validatedData = insertUserSchema.parse(req.body);
    
    // Check if user already exists
    const existingUser = await storage.getUserByUsername(validatedData.username);
    if (existingUser) {
      return res.status(400).json({ message: "Username already taken" });
    }
    
    // Create new user
    const newUser = await storage.createUser(validatedData);
    
    // Remove password from response
    const { password, ...userWithoutPassword } = newUser;
    
    // Set user in session
    if (req.session) {
      req.session.userId = newUser.id;
    }
    
    return res.status(201).json({ 
      message: "User registered successfully", 
      user: userWithoutPassword 
    });
  } catch (error) {
    console.error("Register error:", error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    return res.status(500).json({ message: "Error registering user" });
  }
}

export async function login(req: Request, res: Response) {
  try {
    // Validate input
    const validatedData = loginSchema.parse(req.body);
    
    // Find user
    const user = await storage.getUserByUsername(validatedData.username);
    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }
    
    // Check password (simple comparison for demo)
    if (user.password !== validatedData.password) {
      return res.status(401).json({ message: "Invalid username or password" });
    }
    
    // Set user in session
    if (req.session) {
      req.session.userId = user.id;
    }
    
    // Remove password from response
    const { password, ...userWithoutPassword } = user;
    
    return res.status(200).json({ 
      message: "Login successful", 
      user: userWithoutPassword 
    });
  } catch (error) {
    console.error("Login error:", error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    return res.status(500).json({ message: "Error logging in" });
  }
}

export async function logout(req: Request, res: Response) {
  if (req.session) {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  } else {
    return res.status(200).json({ message: "Logged out successfully" });
  }
}

export async function getCurrentUser(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // Get user data
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Remove password from response
    const { password, ...userWithoutPassword } = user;
    
    return res.status(200).json({ user: userWithoutPassword });
  } catch (error) {
    console.error("Get current user error:", error);
    return res.status(500).json({ message: "Error getting current user" });
  }
}
