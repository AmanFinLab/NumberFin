import { Request, Response } from "express";
import { generateProblem, generateProblemSet } from "@/lib/math/problemGenerator";

// In-memory storage for streaks
const userStreaks = new Map<number, UserStreakData>();

interface UserStreakData {
  userId: number;
  currentStreak: number;
  bestStreak: number;
  lastCompletedDate: string | null;
  daysCompleted: string[];
}

// In-memory storage for daily challenges
const dailyChallenges = [
  {
    id: "cross-math-1",
    type: "Cross Math Puzzle",
    date: new Date().toISOString(),
    description: "Fill in the missing numbers to make all rows and columns equal the target sum.",
    puzzle: {
      type: "grid",
      size: 3,
      targetSum: 15,
      cells: [
        [4, null, 9],
        [3, 5, null],
        [null, 1, 6]
      ]
    },
    solution: [8, 7, 2]
  },
  {
    id: "div3-133",
    type: "DIV3 #133",
    date: new Date().toISOString(),
    description: "Find numbers that are divisible by 3 in the grid.",
    puzzle: {
      type: "div3",
      grid: [
        [9, 4, 12],
        [7, 15, 2],
        [21, 5, 6]
      ]
    },
    solution: [9, 12, 15, 21, 6]
  },
  {
    id: "open-229",
    type: "OPEN #229",
    date: new Date().toISOString(),
    description: "Solve the open-ended problem with multiple solutions.",
    puzzle: {
      type: "open",
      question: "Find three numbers that sum to 20 and have a product of 60."
    },
    solution: "Multiple valid solutions, e.g., [2, 6, 12], [3, 4, 13]"
  }
];

export async function getDailyChallenges(req: Request, res: Response) {
  try {
    return res.status(200).json(dailyChallenges);
  } catch (error) {
    console.error("Get daily challenges error:", error);
    return res.status(500).json({ message: "Error getting daily challenges" });
  }
}

export async function getDailyChallenge(req: Request, res: Response) {
  try {
    const challengeId = req.params.id;
    
    // Find the challenge by ID
    const challenge = dailyChallenges.find(c => c.id === challengeId);
    
    if (!challenge) {
      return res.status(404).json({ message: "Challenge not found" });
    }
    
    return res.status(200).json(challenge);
  } catch (error) {
    console.error("Get daily challenge error:", error);
    return res.status(500).json({ message: "Error getting daily challenge" });
  }
}

export async function getUserStreak(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.session.userId;
    
    // Get or create user streak data
    let streakData = userStreaks.get(userId);
    if (!streakData) {
      streakData = {
        userId,
        currentStreak: 0,
        bestStreak: 0,
        lastCompletedDate: null,
        daysCompleted: []
      };
      userStreaks.set(userId, streakData);
    }
    
    return res.status(200).json(streakData);
  } catch (error) {
    console.error("Get streak error:", error);
    return res.status(500).json({ message: "Error getting streak data" });
  }
}

export async function updateStreak(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.session.userId;
    const { date, currentStreak, bestStreak } = req.body;
    
    // Get or create user streak data
    let streakData = userStreaks.get(userId);
    if (!streakData) {
      streakData = {
        userId,
        currentStreak: 0,
        bestStreak: 0,
        lastCompletedDate: null,
        daysCompleted: []
      };
    }
    
    // Update streak data
    streakData.currentStreak = currentStreak;
    streakData.bestStreak = bestStreak;
    streakData.lastCompletedDate = date;
    
    // Add date to completed days if not already included
    if (!streakData.daysCompleted.includes(date)) {
      streakData.daysCompleted.push(date);
    }
    
    // Save updated streak data
    userStreaks.set(userId, streakData);
    
    return res.status(200).json({ message: "Streak updated" });
  } catch (error) {
    console.error("Update streak error:", error);
    return res.status(500).json({ message: "Error updating streak" });
  }
}

export async function resetStreak(req: Request, res: Response) {
  try {
    // Check if user is logged in
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.session.userId;
    
    // Reset streak data
    const streakData = {
      userId,
      currentStreak: 0,
      bestStreak: 0,
      lastCompletedDate: null,
      daysCompleted: []
    };
    
    userStreaks.set(userId, streakData);
    
    return res.status(200).json({ message: "Streak reset" });
  } catch (error) {
    console.error("Reset streak error:", error);
    return res.status(500).json({ message: "Error resetting streak" });
  }
}
