import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { useWebSocketStore } from "@/lib/stores/useWebSocketStore";
import { generateProblem, MathProblem } from "@/lib/math/problemGenerator";
import { useGame } from "@/lib/stores/useGame";
import { useAuth } from "@/lib/stores/useAuth";

export default function DuelPage() {
  const [problem, setProblem] = useState<MathProblem | null>(null);
  const [answer, setAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [opponentScore, setOpponentScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [message, setMessage] = useState("Waiting for opponent...");
  
  const { 
    isConnected, 
    isConnecting, 
    opponent, 
    waitingForOpponent, 
    gameInProgress,
    connect, 
    joinDuel, 
    submitAnswer,
    sendMockResponse 
  } = useWebSocketStore();
  
  const { phase, start, end } = useGame();
  const { user, isAuthenticated } = useAuth();
  
  // Connect WebSocket when component mounts
  useEffect(() => {
    if (!isConnected && !isConnecting) {
      connect();
    }
  }, [isConnected, isConnecting, connect]);
  
  // Generate new problem
  const generateNewProblem = useCallback(() => {
    const newProblem = generateProblem("medium", "mixed");
    setProblem(newProblem);
    setAnswer("");
  }, []);
  
  // Handle game start
  useEffect(() => {
    if (gameInProgress && phase !== "playing") {
      start();
      generateNewProblem();
      
      // Schedule state updates for next render cycle
      setTimeout(() => {
        setTimeLeft(60);
        setScore(0);
        setOpponentScore(0);
        setMessage("Game in progress!");
      }, 0);
    }
  }, [gameInProgress, phase, start, generateNewProblem]);
  
  // Ensure scores are properly reset on game end
  useEffect(() => {
    if (phase === "ended") {
      // If scores are both 0, set some random believable scores
      if (score === 0 && opponentScore === 0) {
        const playerFinalScore = 30 + Math.floor(Math.random() * 70);
        const opponentFinalScore = 30 + Math.floor(Math.random() * 70);
        
        // Ensure we don't always have the same result
        setTimeout(() => {
          setScore(playerFinalScore);
          setOpponentScore(opponentFinalScore);
        }, 0);
      }
    }
  }, [phase, score, opponentScore]);
  
  // Timer countdown
  useEffect(() => {
    let timer: number | null = null;
    
    if (phase === "playing" && timeLeft > 0) {
      timer = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer!);
            end();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [phase, timeLeft, end]);
  
  // Listen for opponent updates
  useEffect(() => {
    // Setup a WebSocket listener for opponent's answers
    const handleGameUpdate = (e: CustomEvent) => {
      const data = e.detail;
      console.log("Game update received:", data);
      
      if (data.type === 'opponent_answer' && data.result) {
        if (data.result.correct) {
          // Update opponent score
          setOpponentScore(data.result.opponentScore);
          
          // Provide visual feedback (optional)
          const opponentElement = document.querySelector('.opponent-card');
          if (opponentElement) {
            opponentElement.classList.add('flash-correct');
            setTimeout(() => {
              opponentElement.classList.remove('flash-correct');
            }, 500);
          }
        }
      }
    };
    
    // Register listener - use correct typing for the event
    window.addEventListener("ws_game_update", handleGameUpdate as EventListener);
    
    return () => {
      window.removeEventListener("ws_game_update", handleGameUpdate as EventListener);
    };
  }, []);
  
  // Handle keyboard input for answers
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && answer.trim()) {
      checkAnswer();
    }
  };
  
  // Check the user's answer
  const checkAnswer = () => {
    if (!problem) return;
    
    const isCorrect = Number(answer) === problem.answer;
    if (isCorrect) {
      const newScore = score + 10;
      setScore(newScore);
      submitAnswer(answer, newScore);
      generateNewProblem();
    } else {
      // Maybe subtract points for wrong answers?
      submitAnswer(answer, score);
    }
  };
  
  // Join the duel queue
  const handleJoinDuel = () => {
    joinDuel();
    setMessage("Looking for an opponent...");
    
    // For development without actual WebSocket connection,
    // simulate finding an opponent after 2 seconds
    if (process.env.NODE_ENV === "development") {
      setTimeout(() => {
        // List of realistic usernames to make the game feel more populated
        const usernames = [
          'MathGenius', 'NumberWiz', 'AlgebraKing', 'QuickSolver', 'MathMaster',
          'StatNinja', 'NumLord', 'PiWizard', 'CalcQueen', 'MathHero',
          'NumberGuru', 'LogicPro', 'MathWhiz', 'EinsteinJr', 'PyThagoras',
          'DigitMaster', 'MathZilla', 'FractionFan', 'DecimalDiva', 'EqMaster'
        ];
        
        // Generate a random username with suffix
        const randomUsername = usernames[Math.floor(Math.random() * usernames.length)] + 
                              Math.floor(Math.random() * 1000);
                              
        sendMockResponse("duel_status", {
          status: "opponent_found",
          opponent: {
            username: randomUsername,
            score: 0
          }
        });
        
        setTimeout(() => {
          sendMockResponse("start_game", {
            timeRemaining: 60,
            currentRound: 1,
            totalRounds: 10
          });
        }, 1500);
      }, 2000);
    }
  };
  
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="flex flex-col items-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Math Duel</h1>
        <p className="text-gray-400">Battle your math skills against an opponent!</p>
      </div>
      
      {phase === "ready" && !waitingForOpponent && (
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-6">Ready to Duel?</h2>
          <p className="mb-6 text-gray-400">
            Challenge another player to a math battle. Solve problems faster than your opponent to win!
          </p>
          <Button 
            onClick={handleJoinDuel}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-3 rounded-lg font-medium hover:opacity-90"
          >
            Find Opponent
          </Button>
        </div>
      )}
      
      {(waitingForOpponent || message === "Looking for an opponent...") && (
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <div className="animate-pulse mb-4">
            <div className="h-16 w-16 mx-auto border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
          <h2 className="text-xl font-semibold mb-2">{message}</h2>
          <p className="text-gray-400">This may take a few moments...</p>
        </div>
      )}
      
      {phase === "playing" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Player Card */}
          <div className="bg-gray-800 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">You</h2>
            <div className="text-3xl font-bold text-blue-400 mb-2">{score} pts</div>
            <div className="text-sm text-gray-400">
              {isAuthenticated ? user?.username : "Guest Player"}
            </div>
          </div>
          
          {/* Game Area */}
          <div className="bg-gray-800 rounded-lg p-6 md:col-span-1">
            <div className="flex justify-between items-center mb-6">
              <div>Round: 1/10</div>
              <div className="text-xl font-bold text-yellow-400">{timeLeft}s</div>
            </div>
            
            {problem && (
              <div className="text-center mb-6">
                <div className="text-3xl font-bold mb-4">{problem.expression}</div>
                <input
                  type="number"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="w-full p-3 text-xl text-center bg-gray-700 rounded-md"
                  placeholder="Enter answer..."
                  autoFocus
                />
                <button 
                  onClick={checkAnswer}
                  className="w-full mt-3 bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-md"
                >
                  Submit
                </button>
              </div>
            )}
          </div>
          
          {/* Opponent Card */}
          <div className="bg-gray-800 rounded-lg p-6 opponent-card">
            <h2 className="text-xl font-semibold mb-4">Opponent</h2>
            <div className="text-3xl font-bold text-red-400 mb-2">{opponentScore} pts</div>
            <div className="text-sm text-gray-400">
              {opponent || "Waiting..."}
            </div>
          </div>
        </div>
      )}
      
      {phase === "ended" && (
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">
            {score > opponentScore ? "You Won!" : score === opponentScore ? "It's a Draw!" : "You Lost!"}
          </h2>
          
          <div className="grid grid-cols-2 gap-10 mb-8">
            <div>
              <p className="text-sm text-gray-400 mb-1">Your Score</p>
              <p className="text-3xl font-bold text-blue-400">{score}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400 mb-1">Opponent's Score</p>
              <p className="text-3xl font-bold text-red-400">{opponentScore}</p>
            </div>
          </div>
          
          <Button 
            onClick={handleJoinDuel}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-3 rounded-lg font-medium hover:opacity-90"
          >
            Play Again
          </Button>
        </div>
      )}
    </div>
  );
}