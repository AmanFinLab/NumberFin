import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import UserStats from "@/components/profiles/UserStats";
import StreakDisplay from "@/components/streaks/StreakDisplay";
import { apiRequest } from "@/lib/queryClient";
import { useStreak } from "@/lib/stores/useStreak";

export default function ProfilePage() {
  const { streakData } = useStreak();
  const [activeTab, setActiveTab] = useState("stats");
  
  // Fetch user profile data
  const { data: userData, isLoading } = useQuery({
    queryKey: ["/api/user/profile"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/user/profile", undefined);
      return res.json();
    },
  });
  
  // Mock data for demo
  const mockUserData = {
    username: "amanchaudhary",
    joinDate: "2022-09-15",
    gamesPlayed: 627068,
    highestStreak: 10,
    averageSpeed: 2.4,
    correctAnswers: 58234,
    totalQuestions: 62751,
    recentGames: [
      { id: 1, type: "1 MIN DUEL", date: "2023-03-22", score: 450, result: "win" },
      { id: 2, type: "FLASH ANZAN", date: "2023-03-22", score: 320, result: "lose" },
      { id: 3, type: "DAILY CHALLENGE", date: "2023-03-21", score: 280, result: "win" },
      { id: 4, type: "1 MIN DUEL", date: "2023-03-21", score: 410, result: "win" },
      { id: 5, type: "ONLINE DUEL", date: "2023-03-20", score: 390, result: "lose" },
    ],
    badges: [
      { id: 1, name: "Math Wizard", description: "Complete 100 challenges" },
      { id: 2, name: "Speed Demon", description: "Answer in under 1 second" },
      { id: 3, name: "Streak Master", description: "Maintain a 7-day streak" },
    ]
  };
  
  // Use mock data if API data is not available
  const userProfile = userData || mockUserData;
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center gap-6 mb-8">
        <Avatar className="size-20 border-4 border-green-500">
          <AvatarImage src="" />
          <AvatarFallback className="bg-green-700 text-white text-2xl">
            {userProfile.username.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        <div>
          <h1 className="text-3xl font-bold">{userProfile.username}</h1>
          <p className="text-gray-400">
            Joined {new Date(userProfile.joinDate).toLocaleDateString()}
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="md:col-span-2">
          <UserStats
            username={userProfile.username}
            gamesPlayed={userProfile.gamesPlayed}
            highestStreak={userProfile.highestStreak}
            averageSpeed={userProfile.averageSpeed}
            correctAnswers={userProfile.correctAnswers}
            totalQuestions={userProfile.totalQuestions}
          />
        </div>
        
        <div>
          <StreakDisplay
            currentStreak={streakData.currentStreak}
            bestStreak={streakData.bestStreak}
            daysCompleted={streakData.daysCompleted}
          />
        </div>
      </div>
      
      <Tabs defaultValue="stats" onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="stats">Recent Games</TabsTrigger>
          <TabsTrigger value="badges">Badges</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="stats">
          <Card className="border-0 bg-gray-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Recent Game History</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="divide-y divide-gray-800">
                {userProfile.recentGames.map((game) => (
                  <div key={game.id} className="py-3 flex items-center justify-between">
                    <div>
                      <p className="font-medium">{game.type}</p>
                      <p className="text-sm text-gray-400">{game.date}</p>
                    </div>
                    <div className="flex items-center">
                      <span className="mr-3 font-mono font-bold">{game.score}</span>
                      <span className={`px-2 py-1 rounded text-xs ${
                        game.result === "win" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                      }`}>
                        {game.result.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="badges">
          <Card className="border-0 bg-gray-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Earned Badges</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {userProfile.badges.map((badge) => (
                  <div key={badge.id} className="bg-gray-800 p-4 rounded-lg">
                    <div className="size-12 bg-green-500/20 rounded-full flex items-center justify-center mb-3">
                      <span className="text-2xl">🏆</span>
                    </div>
                    <h3 className="font-bold">{badge.name}</h3>
                    <p className="text-sm text-gray-400">{badge.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card className="border-0 bg-gray-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Account Settings</CardTitle>
            </CardHeader>
            
            <CardContent>
              <p className="text-gray-400">
                Account settings will be available in a future update.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
