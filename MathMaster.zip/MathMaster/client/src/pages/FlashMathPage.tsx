import { useState, useEffect, useCallback } from "react";
import { useGame } from "@/lib/stores/useGame";
import { useMathDuel } from "@/lib/stores/useMathDuel";
import { generateProblem, MathProblem, DifficultyLevel, MathProblemType } from "@/lib/math/problemGenerator";
import { Button } from "@/components/ui/button";
import { useStats } from "@/lib/stores/useStats";
import { useAudio } from "@/lib/stores/useAudio";

export default function FlashMathPage() {
  const [problem, setProblem] = useState<MathProblem | null>(null);
  const [answer, setAnswer] = useState("");
  const [difficulty, setDifficulty] = useState<DifficultyLevel>("medium");
  const [problemType, setProblemType] = useState<MathProblemType>("mixed");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  
  const { phase, start, end, restart } = useGame();
  const { 
    score, 
    timeLeft, 
    answeredCount, 
    correctCount,
    startGame, 
    endGame, 
    answerProblem, 
    resetGame 
  } = useMathDuel();
  
  const { incrementGamesPlayed, addResult } = useStats();
  const { playHit, playSuccess } = useAudio();
  
  // Generate a new problem
  const generateNewProblem = useCallback(() => {
    const newProblem = generateProblem(difficulty, problemType);
    setProblem(newProblem);
    setAnswer("");
    setFeedback(null);
  }, [difficulty, problemType]);
  
  // Start a new game session
  const handleStartGame = useCallback(() => {
    startGame();
    start();
    generateNewProblem();
    incrementGamesPlayed();
  }, [startGame, start, generateNewProblem, incrementGamesPlayed]);
  
  // Complete reset and restart function - fixed implementation
  const resetAndRestart = useCallback(() => {
    console.log("resetAndRestart called");
    
    // First reset UI state
    setAnswer("");
    setFeedback(null);
    setProblem(null);
    
    // Then reset game state
    resetGame();
    end(); // Ensure we're in "ended" state
    
    console.log("Game state reset complete");
    
    // Use a sequence of delayed operations to ensure proper state transitions
    setTimeout(() => {
      // First transition to "ready" state
      restart();
      console.log("Transitioning to ready state");
      
      // Then schedule transition to "playing" state and start game
      setTimeout(() => {
        start(); // Set game phase to "playing"
        startGame(); // Start the MathDuel timer/score tracking
        generateNewProblem(); // Generate the first problem
        incrementGamesPlayed(); // Increment games played counter
        console.log("New game started successfully");
      }, 100);
    }, 100);
  }, [resetGame, end, restart, start, startGame, generateNewProblem, incrementGamesPlayed]);
  
  // End the current game
  const handleEndGame = useCallback(() => {
    endGame();
    end();
    // Record results
    if (answeredCount > 0) {
      const averageTimePerProblem = Math.max(0.1, Math.floor(60 - timeLeft) / answeredCount);
      addResult(
        correctCount > 0, 
        averageTimePerProblem, 
        score
      );
    }
  }, [endGame, end, answeredCount, timeLeft, correctCount, addResult, score]);
  
  // Monitor timeLeft for game over
  useEffect(() => {
    if (phase === "playing" && timeLeft <= 0) {
      // Ensure game ends when time reaches zero
      handleEndGame();
    }
  }, [phase, timeLeft, handleEndGame]);
  
  // Check the submitted answer
  const checkAnswer = useCallback(() => {
    if (!problem || !answer.trim()) return;
    
    const userAnswer = parseInt(answer, 10);
    const isCorrect = userAnswer === problem.answer;
    
    // Update feedback and play sound
    setFeedback(isCorrect ? "correct" : "incorrect");
    if (isCorrect) {
      playSuccess?.();
    } else {
      playHit?.();
    }
    
    // Update game state
    answerProblem(isCorrect);
    
    // Generate a new problem after a short delay
    setTimeout(() => {
      generateNewProblem();
    }, 500);
    
  }, [problem, answer, answerProblem, generateNewProblem, playHit, playSuccess]);
  
  // Handle keyboard input for answers
  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter" && answer.trim() && phase === "playing") {
      checkAnswer();
    }
  };
  
  // Set up keyboard listeners
  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);
  
  // Reset the game when component unmounts
  useEffect(() => {
    return () => {
      resetGame();
      end();
    };
  }, [resetGame, end]);
  
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="flex flex-col items-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Flash Math</h1>
        <p className="text-gray-400">Solve math problems as quickly as you can!</p>
      </div>
      
      {phase === "ready" && (
        <div className="bg-gray-800 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-6 text-center">Choose Your Challenge</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Difficulty Selection */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Difficulty</h3>
              <div className="grid grid-cols-2 gap-3">
                {(["easy", "medium", "hard", "expert"] as DifficultyLevel[]).map((level) => (
                  <Button
                    key={level}
                    onClick={() => setDifficulty(level)}
                    variant={difficulty === level ? "default" : "outline"}
                    className={`capitalize ${
                      difficulty === level 
                        ? "bg-blue-600 hover:bg-blue-700" 
                        : "text-gray-300"
                    }`}
                  >
                    {level}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Problem Type Selection */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Problem Type</h3>
              <div className="grid grid-cols-2 gap-3">
                {(["addition", "subtraction", "multiplication", "division", "mixed"] as MathProblemType[]).map((type) => (
                  <Button
                    key={type}
                    onClick={() => setProblemType(type)}
                    variant={problemType === type ? "default" : "outline"}
                    className={`capitalize ${
                      problemType === type 
                        ? "bg-blue-600 hover:bg-blue-700" 
                        : "text-gray-300"
                    }`}
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="text-center">
            <Button 
              onClick={handleStartGame}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white text-lg font-medium rounded-lg hover:opacity-90"
            >
              Start Game
            </Button>
          </div>
        </div>
      )}
      
      {phase === "playing" && (
        <div className="bg-gray-800 rounded-lg p-8">
          {/* Game Stats Bar */}
          <div className="flex justify-between items-center mb-8 border-b border-gray-700 pb-4">
            <div>
              <span className="text-sm text-gray-400">Score</span>
              <div className="text-2xl font-bold text-blue-400">{score}</div>
            </div>
            <div>
              <span className="text-sm text-gray-400">Time Left</span>
              <div className="text-2xl font-bold text-yellow-400">{timeLeft}s</div>
            </div>
            <div>
              <span className="text-sm text-gray-400">Correct</span>
              <div className="text-2xl font-bold text-green-400">{correctCount}/{answeredCount}</div>
            </div>
          </div>
          
          {/* Problem Display */}
          {problem && (
            <div className="text-center mb-8">
              <div className={`text-4xl font-bold mb-8 transition-all duration-300 ${
                feedback === "correct" 
                  ? "text-green-400 scale-110" 
                  : feedback === "incorrect" 
                    ? "text-red-400 scale-95"
                    : "text-white"
              }`}>
                {problem.expression}
              </div>
              
              <div className="max-w-md mx-auto">
                <input
                  type="number"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  className="w-full p-4 text-2xl text-center bg-gray-700 rounded-lg mb-4"
                  placeholder="Enter your answer..."
                  autoFocus
                />
                
                <Button 
                  onClick={checkAnswer}
                  className="w-full py-3 text-lg bg-blue-600 hover:bg-blue-700"
                >
                  Submit Answer
                </Button>
              </div>
            </div>
          )}
          
          {/* End Game Button */}
          <div className="text-center mt-6">
            <Button 
              onClick={handleEndGame}
              variant="outline"
              className="text-gray-400 hover:text-white"
            >
              End Game
            </Button>
          </div>
        </div>
      )}
      
      {phase === "ended" && (
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <h2 className="text-3xl font-bold mb-2">Game Over!</h2>
          <p className="text-gray-400 mb-8">Here's how you did:</p>
          
          <div className="grid grid-cols-3 gap-8 mb-8">
            <div className="bg-gray-700 p-6 rounded-lg">
              <p className="text-sm text-gray-400 mb-1">Final Score</p>
              <p className="text-3xl font-bold text-blue-400">{score}</p>
            </div>
            <div className="bg-gray-700 p-6 rounded-lg">
              <p className="text-sm text-gray-400 mb-1">Problems Solved</p>
              <p className="text-3xl font-bold text-purple-400">{answeredCount}</p>
            </div>
            <div className="bg-gray-700 p-6 rounded-lg">
              <p className="text-sm text-gray-400 mb-1">Accuracy</p>
              <p className="text-3xl font-bold text-green-400">
                {answeredCount > 0 
                  ? `${Math.round((correctCount / answeredCount) * 100)}%` 
                  : "0%"}
              </p>
            </div>
          </div>
          
          <Button 
            onClick={resetAndRestart}
            className="px-8 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white text-lg font-medium rounded-lg hover:opacity-90 mr-4"
          >
            Play Again
          </Button>
          
          <Button 
            onClick={() => {
              console.log("Change Settings clicked");
              resetGame();
              restart();
            }}
            variant="outline"
            className="px-8 py-3 text-white"
          >
            Change Settings
          </Button>
        </div>
      )}
    </div>
  );
}