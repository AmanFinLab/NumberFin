import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { useAudio } from "@/lib/stores/useAudio";

interface MathTrick {
  id: string;
  title: string;
  description: string;
  example: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  category: 'multiplication' | 'addition' | 'subtraction' | 'division' | 'general';
}

export default function LearnPage() {
  const { playSuccess } = useAudio();
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  
  const tricks: MathTrick[] = [
    {
      id: "mult-by-11",
      title: "Multiply by 11",
      description: "For 2-digit numbers, to multiply by 11, add the two digits and place the result between the two digits. If the sum is greater than 9, carry the 1 to the left digit.",
      example: "11 × 25: First write down 2 and 5. Then, 2 + 5 = 7. Place 7 between 2 and 5: 275",
      difficulty: "beginner",
      category: "multiplication"
    },
    {
      id: "square-end-5",
      title: "Square Numbers Ending in 5",
      description: "To square a number ending in 5, multiply the tens digit by the next whole number and append 25.",
      example: "35²: 3 × 4 = 12, so the answer is 1225",
      difficulty: "beginner",
      category: "multiplication"
    },
    {
      id: "mult-by-9",
      title: "Multiply by 9 Using Your Hands",
      description: "Hold out both hands with fingers extended. To multiply 9 by a number (1-10), fold down that finger counting from the left. The number of fingers to the left is the tens digit, to the right is the ones digit.",
      example: "9 × 7: Fold down the 7th finger. There are 6 fingers to the left and 3 to the right, so 9 × 7 = 63",
      difficulty: "beginner",
      category: "multiplication"
    },
    {
      id: "percentage-conversion",
      title: "Mental Percentage Conversion",
      description: "To find 10% of a number, move the decimal point one place left. For 1%, move it two places.",
      example: "10% of 340 = 34, 1% of 340 = 3.4, 5% of 340 = half of 34 = 17",
      difficulty: "beginner",
      category: "multiplication"
    },
    {
      id: "doubles-addition",
      title: "Using Doubles for Addition",
      description: "When adding, try to find doubles which are often easier to calculate, then adjust as needed.",
      example: "8 + 9: This is close to 8 + 8 = 16, so 8 + 9 = 16 + 1 = 17",
      difficulty: "beginner",
      category: "addition"
    },
    {
      id: "mult-by-factors",
      title: "Multiply Using Factors",
      description: "Break down difficult multiplications into simpler ones using factors.",
      example: "17 × 6: Think of 6 as 2 × 3, so calculate 17 × 2 = 34, then 34 × 3 = 102",
      difficulty: "intermediate",
      category: "multiplication"
    },
    {
      id: "difference-squares",
      title: "Difference of Squares",
      description: "For numbers that differ by 2, you can square the middle number and subtract 1.",
      example: "21 × 19: These differ by 2 with 20 in the middle. 20² = 400, 400 - 1 = 399",
      difficulty: "intermediate",
      category: "multiplication"
    },
    {
      id: "complements",
      title: "Using Complements",
      description: "For addition that crosses tens, use complements to make it easier.",
      example: "8 + 7: 8 needs 2 more to reach 10, so take 2 from 7, leaving 5: 10 + 5 = 15",
      difficulty: "beginner",
      category: "addition"
    },
    {
      id: "mult-11-advanced",
      title: "Advanced Multiplication by 11",
      description: "For 3-digit numbers, multiply by 11 by adding each adjacent pair of digits, carrying if needed.",
      example: "11 × 143: Write 1, then 1+4=5, then 4+3=7, then 3. So 11 × 143 = 1573",
      difficulty: "advanced",
      category: "multiplication"
    },
    {
      id: "vedic-subtraction",
      title: "Vedic Subtraction",
      description: "Subtract from the next power of 10, then complement.",
      example: "1000 - 387: Compute 10-3=7, 10-8=2, 10-7=3. Result: 613",
      difficulty: "intermediate",
      category: "subtraction"
    },
    {
      id: "division-by-5",
      title: "Quick Division by 5",
      description: "To divide by 5, multiply by 2 and then divide by 10 (move decimal point).",
      example: "85 ÷ 5: 85 × 2 = 170, then 170 ÷ 10 = 17",
      difficulty: "beginner",
      category: "division"
    },
    {
      id: "squaring-tricks",
      title: "Squaring Using Difference of Squares",
      description: "Use (a + b)(a - b) = a² - b² to compute squares more easily.",
      example: "48²: Think of 48 as 50 - 2. So 48² = 50² - 2 × 50 × 2 + 2² = 2500 - 200 + 4 = 2304",
      difficulty: "advanced",
      category: "multiplication"
    }
  ];
  
  const filteredTricks = selectedDifficulty === "all" 
    ? tricks 
    : tricks.filter(trick => trick.difficulty === selectedDifficulty);
  
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };
  
  return (
    <div className="container mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-10"
      >
        <h1 className="text-3xl font-bold mb-2">Math Tricks & Techniques</h1>
        <p className="text-gray-400 max-w-3xl">
          Improve your mental math skills with these clever techniques. Practice these methods to solve calculations faster and more accurately in your games.
        </p>
      </motion.div>
      
      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-6">
          <TabsTrigger 
            value="all"
            onClick={() => {
              setSelectedDifficulty("all");
              playSuccess?.();
            }}
          >
            All Levels
          </TabsTrigger>
          <TabsTrigger 
            value="beginner"
            onClick={() => {
              setSelectedDifficulty("beginner");
              playSuccess?.();
            }}
          >
            Beginner
          </TabsTrigger>
          <TabsTrigger 
            value="intermediate"
            onClick={() => {
              setSelectedDifficulty("intermediate");
              playSuccess?.();
            }}
          >
            Intermediate
          </TabsTrigger>
          <TabsTrigger 
            value="advanced"
            onClick={() => {
              setSelectedDifficulty("advanced");
              playSuccess?.();
            }}
          >
            Advanced
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value={selectedDifficulty}>
          <motion.div 
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredTricks.map((trick) => (
              <motion.div key={trick.id} variants={item}>
                <Card className="h-full overflow-hidden border-t-4 hover:shadow-lg transition-shadow duration-300" 
                  style={{ 
                    borderTopColor: trick.difficulty === 'beginner' 
                      ? '#4CAF50' 
                      : trick.difficulty === 'intermediate' 
                        ? '#2196F3' 
                        : '#FF5722'
                  }}
                >
                  <CardHeader>
                    <CardTitle>{trick.title}</CardTitle>
                    <CardDescription>
                      {trick.category.charAt(0).toUpperCase() + trick.category.slice(1)} • {trick.difficulty.charAt(0).toUpperCase() + trick.difficulty.slice(1)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p>{trick.description}</p>
                      <div className="bg-gray-800 rounded-md p-3 font-mono text-sm">
                        <span className="text-green-400">Example:</span> {trick.example}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </TabsContent>
      </Tabs>
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="mt-10 p-6 bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-lg text-center"
      >
        <h2 className="text-2xl font-bold mb-3">Practice Makes Perfect!</h2>
        <p className="text-gray-300 mb-4">
          The more you practice these techniques, the more natural they'll become. Try them in your next math challenge!
        </p>
      </motion.div>
    </div>
  );
}