import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LeaderboardItem from "@/components/leaderboard/LeaderboardItem";
import { apiRequest } from "@/lib/queryClient";

export default function LeaderboardPage() {
  const [activeTab, setActiveTab] = useState("global");
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  
  // Fetch leaderboard data
  const { data: leaderboardData, isLoading } = useQuery({
    queryKey: [`/api/leaderboard/${activeTab}`],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/leaderboard/${activeTab}`, undefined);
      return res.json();
    },
  });
  
  // Simulate user fetch for demo
  useEffect(() => {
    // In a real app, this would be fetched from API or auth context
    setCurrentUser("amanchaudhary");
  }, []);
  
  // Mock data if API is not connected
  const mockLeaderboard = [
    { rank: 1, username: "mathgenius", score: 9857 },
    { rank: 2, username: "numberwizard", score: 8932 },
    { rank: 3, username: "calculatorkiller", score: 8654 },
    { rank: 4, username: "amanchaudhary", score: 7850 },
    { rank: 5, username: "speedymath", score: 7544 },
    { rank: 6, username: "algebrazorro", score: 7211 },
    { rank: 7, username: "mathlete99", score: 6998 },
    { rank: 8, username: "numbercrafter", score: 6752 },
    { rank: 9, username: "arithmeticace", score: 6504 },
    { rank: 10, username: "mathninja", score: 6321 },
  ];
  
  const displayData = leaderboardData?.users || mockLeaderboard;
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Leaderboard</h1>
      
      <Tabs defaultValue="global" onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="global">Global</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="friends">Friends</TabsTrigger>
        </TabsList>
        
        <TabsContent value="global" className="space-y-4">
          <Card className="border-0 bg-gray-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Global Rankings</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-3">
                {isLoading ? (
                  <p>Loading leaderboard...</p>
                ) : (
                  displayData.map((user: any) => (
                    <LeaderboardItem
                      key={user.rank}
                      rank={user.rank}
                      username={user.username}
                      score={user.score}
                      isCurrentUser={user.username === currentUser}
                    />
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="weekly" className="space-y-4">
          <Card className="border-0 bg-gray-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Weekly Rankings</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-3">
                {/* Use same mock data for demo */}
                {mockLeaderboard
                  .sort((a, b) => b.score - a.score)
                  .slice(0, 10)
                  .map((user, index) => (
                    <LeaderboardItem
                      key={index}
                      rank={index + 1}
                      username={user.username}
                      score={Math.floor(user.score * 0.4)} // Smaller scores for weekly
                      isCurrentUser={user.username === currentUser}
                    />
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="friends" className="space-y-4">
          <Card className="border-0 bg-gray-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Friends Rankings</CardTitle>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-3">
                {/* Use filtered mock data for demo */}
                {mockLeaderboard
                  .filter((user) => ['mathgenius', 'numberwizard', 'amanchaudhary'].includes(user.username))
                  .sort((a, b) => b.score - a.score)
                  .map((user, index) => (
                    <LeaderboardItem
                      key={index}
                      rank={index + 1}
                      username={user.username}
                      score={user.score}
                      isCurrentUser={user.username === currentUser}
                    />
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
