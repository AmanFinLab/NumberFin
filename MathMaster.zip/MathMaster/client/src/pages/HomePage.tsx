import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/stores/useAuth";
import { Button } from "@/components/ui/button";
import GameCard from "@/components/games/GameCard";
import DuelCard from "@/components/games/DuelCard";
import FlashMathCard from "@/components/games/FlashMathCard";
import { Calendar, Calculator, Trophy, Brain, Users, Activity, Award } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { useAudio } from "@/lib/stores/useAudio";

export default function HomePage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { playSuccess } = useAudio();
  
  // State for dynamic user counts with initial values
  const [totalUsers, setTotalUsers] = useState(12847);
  const [activeUsers, setActiveUsers] = useState(8429);
  const [activePlayers, setActivePlayers] = useState(3271);
  
  // Function to generate random number within a range
  const getRandomNumber = (min: number, max: number) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };
  
  // Simulate changing user stats
  useEffect(() => {
    const interval = setInterval(() => {
      // Random fluctuation logic - make small adjustments to create natural variations
      setTotalUsers(prev => {
        const change = getRandomNumber(-5, 15); // More likely to increase
        return prev + change;
      });
      
      setActiveUsers(prev => {
        const change = getRandomNumber(-10, 12); 
        return Math.min(Math.max(prev + change, totalUsers * 0.5), totalUsers * 0.7);
      });
      
      setActivePlayers(prev => {
        const change = getRandomNumber(-8, 10);
        return Math.min(Math.max(prev + change, activeUsers * 0.3), activeUsers * 0.45);
      });
    }, 5000); // Update every 5 seconds
    
    return () => clearInterval(interval);
  }, [totalUsers, activeUsers]);
  
  // Format numbers with commas
  const formatNumber = (num: number) => {
    return Math.floor(num).toLocaleString();
  };
  
  return (
    <div className="container mx-auto p-6">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-gradient-to-r from-blue-800 to-indigo-900 rounded-xl p-8 mb-10"
      >
        <div className="max-w-3xl mx-auto text-center">
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-4xl md:text-5xl font-bold mb-4 text-white"
          >
            Challenge Your Math Skills
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="text-xl text-blue-100 mb-8"
          >
            Test your speed and accuracy with mental math games. Compete with friends or improve your personal best!
          </motion.p>
          
          {/* Live Stats Display */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="flex flex-wrap justify-center gap-4 mb-8 text-white"
          >
            <div className="bg-blue-600/30 backdrop-blur-sm px-5 py-3 rounded-lg flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-300" />
              <div>
                <div className="text-sm text-blue-200">Total Users</div>
                <div className="font-bold">{formatNumber(totalUsers)}</div>
              </div>
            </div>
            
            <div className="bg-blue-600/30 backdrop-blur-sm px-5 py-3 rounded-lg flex items-center">
              <Activity className="w-5 h-5 mr-2 text-green-300" />
              <div>
                <div className="text-sm text-blue-200">Online Now</div>
                <div className="font-bold">{formatNumber(activeUsers)}</div>
              </div>
            </div>
            
            <div className="bg-blue-600/30 backdrop-blur-sm px-5 py-3 rounded-lg flex items-center">
              <Award className="w-5 h-5 mr-2 text-yellow-300" />
              <div>
                <div className="text-sm text-blue-200">Playing Now</div>
                <div className="font-bold">{formatNumber(activePlayers)}</div>
              </div>
            </div>
          </motion.div>
          
          {!isAuthenticated ? (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="flex flex-wrap justify-center gap-4"
            >
              <Button 
                onClick={() => navigate("/login")}
                className="bg-white text-blue-900 hover:bg-blue-50 px-6 py-3 text-lg font-medium rounded-lg"
              >
                Sign In
              </Button>
              <Button 
                onClick={() => {
                  navigate("/register");
                  playSuccess?.();
                }}
                className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 text-lg font-medium rounded-lg"
              >
                Sign Up
              </Button>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="inline-block bg-blue-700/50 px-6 py-3 rounded-lg"
            >
              <p className="text-blue-100">
                Welcome back, <span className="font-bold text-white">{user?.username}</span>!
              </p>
            </motion.div>
          )}
        </div>
      </motion.div>
      
      {/* Game Categories */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="mb-12"
      >
        <h2 className="text-2xl font-bold mb-6">Choose Your Challenge</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Flash Math Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
          >
            <FlashMathCard 
              title="Flash Math" 
              subtitle="Test your speed with rapid-fire math problems" 
              onPlay={() => {
                navigate("/flash-math");
                playSuccess?.();
              }}
            />
          </motion.div>
          
          {/* Math Duel Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
          >
            <DuelCard 
              title="Math Duel"
              subtitle="Challenge other players to a math battle"
              colorScheme="blue"
              onPlay={() => {
                navigate("/duel");
                playSuccess?.();
              }}
            />
          </motion.div>
          
          {/* Daily Challenge Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
          >
            <GameCard
              title="Daily Challenge"
              subtitle="A new math puzzle every day to keep your skills sharp"
              icon={<Calendar className="w-8 h-8" />}
              colorScheme="purple"
              onClick={() => {
                navigate("/daily-challenge");
                playSuccess?.();
              }}
            />
          </motion.div>
        </div>
      </motion.div>
      
      {/* Stats and Leaderboard Section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10"
      >
        <motion.div 
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 300 }}
          className="bg-gray-800 rounded-lg p-6"
        >
          <div className="flex items-center mb-4">
            <Brain className="w-6 h-6 mr-2 text-blue-400" />
            <h3 className="text-xl font-semibold">Your Stats</h3>
          </div>
          
          {isAuthenticated ? (
            <div className="space-y-4">
              <p className="text-gray-400">
                Track your progress and see how you improve over time.
              </p>
              <Button 
                onClick={() => navigate("/profile")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                View Your Profile
              </Button>
            </div>
          ) : (
            <div>
              <p className="text-gray-400 mb-4">
                Sign in to track your stats and progress.
              </p>
              <Button 
                onClick={() => navigate("/login")}
                variant="outline"
                className="text-blue-400 border-blue-400 hover:bg-blue-900/20"
              >
                Sign In to View Stats
              </Button>
            </div>
          )}
        </motion.div>
        
        <motion.div 
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 300 }}
          className="bg-gray-800 rounded-lg p-6"
        >
          <div className="flex items-center mb-4">
            <Trophy className="w-6 h-6 mr-2 text-yellow-400" />
            <h3 className="text-xl font-semibold">Leaderboards</h3>
          </div>
          
          <p className="text-gray-400 mb-4">
            See how you stack up against other math wizards from around the world.
          </p>
          
          <Button 
            onClick={() => navigate("/leaderboard")}
            className="bg-yellow-600 hover:bg-yellow-700 text-white"
          >
            View Leaderboards
          </Button>
        </motion.div>
      </motion.div>
      
      {/* How It Works Section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.6 }}
        className="bg-gray-800 rounded-lg p-8 mb-10"
      >
        <h2 className="text-2xl font-bold mb-6 text-center">How It Works</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.4 }}
            className="text-center"
          >
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <motion.span 
                animate={{ 
                  scale: [1, 1.2, 1],
                }}
                transition={{ 
                  repeat: Infinity, 
                  repeatDelay: 5,
                  duration: 1 
                }}
                className="text-xl font-bold"
              >
                1
              </motion.span>
            </div>
            <h3 className="text-lg font-semibold mb-2">Choose a Game</h3>
            <p className="text-gray-400">
              Select from different game modes based on your skill level and interest.
            </p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0, duration: 0.4 }}
            className="text-center"
          >
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <motion.span 
                animate={{ 
                  scale: [1, 1.2, 1],
                }}
                transition={{ 
                  repeat: Infinity, 
                  repeatDelay: 5,
                  duration: 1,
                  delay: 0.3
                }}
                className="text-xl font-bold"
              >
                2
              </motion.span>
            </div>
            <h3 className="text-lg font-semibold mb-2">Solve Problems</h3>
            <p className="text-gray-400">
              Complete math problems as quickly and accurately as you can.
            </p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1, duration: 0.4 }}
            className="text-center"
          >
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <motion.span 
                animate={{ 
                  scale: [1, 1.2, 1],
                }}
                transition={{ 
                  repeat: Infinity, 
                  repeatDelay: 5,
                  duration: 1,
                  delay: 0.6
                }}
                className="text-xl font-bold"
              >
                3
              </motion.span>
            </div>
            <h3 className="text-lg font-semibold mb-2">Track Progress</h3>
            <p className="text-gray-400">
              See your stats improve and climb the leaderboard rankings.
            </p>
          </motion.div>
        </div>
      </motion.div>
      
      {/* Get Started CTA */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.6 }}
        className="text-center mb-10"
      >
        <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
        <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
          Jump into a quick game now or sign up to track your progress and compete with others.
        </p>
        
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button 
            onClick={() => {
              navigate("/flash-math");
              playSuccess?.();
            }}
            className="bg-green-600 hover:bg-green-700 text-white text-lg px-8 py-3 rounded-lg"
          >
            Play Now
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}