import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Calendar, CheckSquare, Timer, XSquare } from "lucide-react";
import { useAudio } from "@/lib/stores/useAudio";
import { useStreak } from "@/lib/stores/useStreak";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

export default function DailyChallengePage() {
  const [searchParams] = useSearchParams();
  const challengeId = searchParams.get("id") || "daily";
  const { playHit, playSuccess } = useAudio();
  const { completeDaily } = useStreak();
  
  const [userAnswer, setUserAnswer] = useState("");
  const [gameState, setGameState] = useState<"intro" | "playing" | "complete">("intro");
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  
  // Fetch challenge data
  const { data: challengeData, isLoading } = useQuery({
    queryKey: [`/api/daily-challenge/${challengeId}`],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/daily-challenge/${challengeId}`, undefined);
      return res.json();
    },
  });
  
  // Mock challenge data
  const mockChallenge = {
    id: "daily-1",
    type: "Cross Math Puzzle",
    date: new Date().toISOString(),
    description: "Fill in the missing numbers to make all rows and columns equal the target sum.",
    puzzle: {
      type: "grid",
      size: 3,
      targetSum: 15,
      cells: [
        [4, null, 9],
        [3, 5, null],
        [null, 1, 6]
      ]
    },
    solution: [8, 7, 2]
  };
  
  const challenge = challengeData || mockChallenge;
  
  // Start the challenge
  const startChallenge = () => {
    setGameState("playing");
    setUserAnswer("");
    setIsCorrect(null);
  };
  
  // Submit the answer
  const submitAnswer = () => {
    if (!userAnswer) return;
    
    // For demo purposes using mock data, just check if answer contains expected numbers
    const solutionNumbers = challenge.solution;
    const userNumbers = userAnswer.split(",").map(n => parseInt(n.trim())).filter(n => !isNaN(n));
    
    const correct = solutionNumbers.every(n => userNumbers.includes(n)) && 
                    userNumbers.length === solutionNumbers.length;
    
    if (correct) {
      playSuccess();
      setIsCorrect(true);
      completeDaily(); // Mark daily challenge as completed
    } else {
      playHit();
      setIsCorrect(false);
    }
    
    setGameState("complete");
  };
  
  // Handle key input (for numpad)
  const handleNumPadClick = (value: string) => {
    if (value === "backspace") {
      setUserAnswer(prev => prev.slice(0, -1));
    } else if (value === "submit") {
      submitAnswer();
    } else if (value === "comma") {
      setUserAnswer(prev => prev + ",");
    } else {
      setUserAnswer(prev => prev + value);
    }
  };
  
  // Render puzzle grid based on challenge type
  const renderPuzzle = () => {
    if (challenge.puzzle.type === "grid") {
      return (
        <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto mb-6">
          {challenge.puzzle.cells.flat().map((cell, index) => (
            <div 
              key={index}
              className="size-16 flex items-center justify-center bg-gray-800 rounded-lg text-center text-2xl font-bold"
            >
              {cell !== null ? cell : "?"}
            </div>
          ))}
        </div>
      );
    }
    
    return (
      <div className="text-center mb-6">
        <p className="text-gray-400">{challenge.description}</p>
      </div>
    );
  };
  
  return (
    <div className="max-w-md mx-auto pt-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Daily Challenge</h1>
        <Badge variant="outline" className="flex items-center gap-1">
          <Calendar className="h-3 w-3" />
          <span>{new Date(challenge.date).toLocaleDateString()}</span>
        </Badge>
      </div>
      
      <Card className="mb-8 border-0 bg-gray-900">
        <CardContent className="p-6">
          <div className="flex items-center mb-4">
            <Brain className="h-6 w-6 text-green-500 mr-2" />
            <h2 className="text-xl font-bold">{challenge.type}</h2>
          </div>
          
          {gameState === "intro" && (
            <div className="space-y-4">
              <p className="text-gray-400">
                {challenge.description}
              </p>
              <p className="text-sm text-gray-500">
                Target sum: {challenge.puzzle.targetSum}
              </p>
              <Button 
                className="w-full bg-green-500 hover:bg-green-600 text-white" 
                onClick={startChallenge}
              >
                Start Challenge
              </Button>
            </div>
          )}
          
          {gameState === "playing" && (
            <div className="space-y-6">
              {renderPuzzle()}
              
              <div>
                <label className="text-sm text-gray-400 block mb-2">
                  Your Answer (enter numbers separated by commas):
                </label>
                <div className="bg-gray-800 p-3 rounded-lg">
                  <input
                    type="text"
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    className="bg-transparent text-lg font-medium w-full outline-none"
                    placeholder="Enter your answer..."
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-4 gap-2">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
                  <button
                    key={num}
                    className="bg-gray-800 hover:bg-gray-700 text-white text-lg font-medium rounded-lg p-3"
                    onClick={() => handleNumPadClick(num.toString())}
                  >
                    {num}
                  </button>
                ))}
                <button
                  className="bg-gray-800 hover:bg-gray-700 text-white text-lg font-medium rounded-lg p-3"
                  onClick={() => handleNumPadClick("backspace")}
                >
                  <XSquare className="mx-auto h-5 w-5" />
                </button>
                <button
                  className="bg-gray-800 hover:bg-gray-700 text-white text-lg font-medium rounded-lg p-3"
                  onClick={() => handleNumPadClick("0")}
                >
                  0
                </button>
                <button
                  className="bg-gray-800 hover:bg-gray-700 text-white text-lg font-medium rounded-lg p-3"
                  onClick={() => handleNumPadClick("comma")}
                >
                  ,
                </button>
                <button
                  className="bg-green-600 hover:bg-green-700 text-white text-lg font-medium rounded-lg p-3"
                  onClick={() => handleNumPadClick("submit")}
                >
                  <CheckSquare className="mx-auto h-5 w-5" />
                </button>
              </div>
            </div>
          )}
          
          {gameState === "complete" && (
            <div className="space-y-4 text-center">
              {isCorrect ? (
                <>
                  <div className="text-green-500 text-4xl mb-4">🎉</div>
                  <h3 className="text-xl font-bold text-green-500">Correct Answer!</h3>
                  <p className="text-gray-400">
                    Great job solving today's challenge.
                  </p>
                </>
              ) : (
                <>
                  <div className="text-red-500 text-4xl mb-4">😕</div>
                  <h3 className="text-xl font-bold text-red-500">Incorrect Answer</h3>
                  <p className="text-gray-400">
                    The correct answer was: {challenge.solution.join(", ")}
                  </p>
                </>
              )}
              
              <Button 
                className={cn(
                  "w-full text-white mt-4",
                  isCorrect ? "bg-green-500 hover:bg-green-600" : "bg-gray-700 hover:bg-gray-600"
                )} 
                onClick={() => setGameState("intro")}
              >
                Try Another Challenge
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
