// WebSocket client for connecting to the game server

let ws: WebSocket | null = null;
type MessageHandler = (data: any) => void;
const messageHandlers: { [key: string]: MessageHandler[] } = {};

// Create a WebSocket connection or return the existing one
export function getWebSocket(): WebSocket {
  if (!ws || ws.readyState === WebSocket.CLOSED) {
    // Determine the WebSocket URL based on the current environment
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws/game`;
    
    console.log(`Connecting to WebSocket at ${wsUrl}`);
    ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket connection established');
    };
    
    ws.onclose = () => {
      console.log('WebSocket connection closed');
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type && messageHandlers[data.type]) {
          messageHandlers[data.type].forEach(handler => handler(data));
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
  }
  
  return ws;
}

// Send a message to the server
export function sendMessage(type: string, data: any = {}): void {
  const socket = getWebSocket();
  
  if (socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({
      type,
      ...data
    }));
  } else {
    console.warn('WebSocket not ready, message not sent');
  }
}

// Register a handler for a specific message type
export function onMessage(type: string, handler: MessageHandler): () => void {
  if (!messageHandlers[type]) {
    messageHandlers[type] = [];
  }
  
  messageHandlers[type].push(handler);
  
  // Return a function to remove this handler
  return () => {
    messageHandlers[type] = messageHandlers[type].filter(h => h !== handler);
  };
}

// Close the WebSocket connection
export function closeConnection(): void {
  if (ws) {
    ws.close();
    ws = null;
  }
}