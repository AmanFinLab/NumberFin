// Types for math problems
export type MathProblemType = "addition" | "subtraction" | "multiplication" | "division" | "mixed";
export type DifficultyLevel = "easy" | "medium" | "hard" | "expert";

export interface MathProblem {
  expression: string;
  answer: number;
  type: MathProblemType;
  difficulty: DifficultyLevel;
}

/**
 * Generates a random math problem based on difficulty level
 * @param difficulty The difficulty level of the problem
 * @param type Optional type of math problem (defaults to mixed)
 * @returns A math problem object with expression and answer
 */
export function generateProblem(
  difficulty: DifficultyLevel = "medium",
  type: MathProblemType = "mixed"
): MathProblem {
  // If type is mixed, randomly choose a problem type
  const problemType = type === "mixed" 
    ? ["addition", "subtraction", "multiplication", "division"][
        Math.floor(Math.random() * 4)
      ] as MathProblemType
    : type;
  
  // Generate problem based on type and difficulty
  switch (problemType) {
    case "addition":
      return generateAdditionProblem(difficulty);
    case "subtraction":
      return generateSubtractionProblem(difficulty);
    case "multiplication":
      return generateMultiplicationProblem(difficulty);
    case "division":
      return generateDivisionProblem(difficulty);
    default:
      return generateAdditionProblem(difficulty);
  }
}

/**
 * Generates an addition problem
 */
function generateAdditionProblem(difficulty: DifficultyLevel): MathProblem {
  let a: number, b: number;
  
  switch (difficulty) {
    case "easy":
      a = Math.floor(Math.random() * 10) + 1; // 1-10
      b = Math.floor(Math.random() * 10) + 1; // 1-10
      break;
    case "medium":
      a = Math.floor(Math.random() * 50) + 10; // 10-59
      b = Math.floor(Math.random() * 40) + 10; // 10-49
      break;
    case "hard":
      a = Math.floor(Math.random() * 100) + 50; // 50-149
      b = Math.floor(Math.random() * 100) + 20; // 20-119
      break;
    case "expert":
      a = Math.floor(Math.random() * 500) + 100; // 100-599
      b = Math.floor(Math.random() * 500) + 100; // 100-599
      break;
  }
  
  return {
    expression: `${a} + ${b} = ?`,
    answer: a + b,
    type: "addition",
    difficulty
  };
}

/**
 * Generates a subtraction problem
 */
function generateSubtractionProblem(difficulty: DifficultyLevel): MathProblem {
  let a: number, b: number;
  
  switch (difficulty) {
    case "easy":
      b = Math.floor(Math.random() * 9) + 1; // 1-9
      a = b + Math.floor(Math.random() * 10) + 1; // b+1 to b+10 (ensuring positive result)
      break;
    case "medium":
      b = Math.floor(Math.random() * 40) + 10; // 10-49
      a = b + Math.floor(Math.random() * 50) + 1; // b+1 to b+50
      break;
    case "hard":
      b = Math.floor(Math.random() * 80) + 20; // 20-99
      a = b + Math.floor(Math.random() * 100) + 1; // b+1 to b+100
      break;
    case "expert":
      b = Math.floor(Math.random() * 300) + 100; // 100-399
      a = b + Math.floor(Math.random() * 400) + 100; // b+100 to b+499
      break;
  }
  
  return {
    expression: `${a} - ${b} = ?`,
    answer: a - b,
    type: "subtraction",
    difficulty
  };
}

/**
 * Generates a multiplication problem
 */
function generateMultiplicationProblem(difficulty: DifficultyLevel): MathProblem {
  let a: number, b: number;
  
  switch (difficulty) {
    case "easy":
      a = Math.floor(Math.random() * 5) + 1; // 1-5
      b = Math.floor(Math.random() * 5) + 1; // 1-5
      break;
    case "medium":
      a = Math.floor(Math.random() * 8) + 3; // 3-10
      b = Math.floor(Math.random() * 8) + 3; // 3-10
      break;
    case "hard":
      a = Math.floor(Math.random() * 8) + 5; // 5-12
      b = Math.floor(Math.random() * 8) + 5; // 5-12
      break;
    case "expert":
      a = Math.floor(Math.random() * 15) + 8; // 8-22
      b = Math.floor(Math.random() * 10) + 8; // 8-17
      break;
  }
  
  return {
    expression: `${a} × ${b} = ?`,
    answer: a * b,
    type: "multiplication",
    difficulty
  };
}

/**
 * Generates a division problem (ensuring whole number results)
 */
function generateDivisionProblem(difficulty: DifficultyLevel): MathProblem {
  let a: number, b: number, result: number;
  
  switch (difficulty) {
    case "easy":
      b = Math.floor(Math.random() * 4) + 2; // 2-5
      result = Math.floor(Math.random() * 5) + 1; // 1-5
      a = b * result; // Ensure clean division
      break;
    case "medium":
      b = Math.floor(Math.random() * 8) + 3; // 3-10
      result = Math.floor(Math.random() * 5) + 2; // 2-6
      a = b * result;
      break;
    case "hard":
      b = Math.floor(Math.random() * 10) + 6; // 6-15
      result = Math.floor(Math.random() * 10) + 3; // 3-12
      a = b * result;
      break;
    case "expert":
      b = Math.floor(Math.random() * 15) + 8; // 8-22
      result = Math.floor(Math.random() * 15) + 5; // 5-19
      a = b * result;
      break;
  }
  
  return {
    expression: `${a} ÷ ${b} = ?`,
    answer: result,
    type: "division",
    difficulty
  };
}

/**
 * Generates a set of problems for a challenge
 */
export function generateProblemSet(
  count: number, 
  difficulty: DifficultyLevel = "medium",
  type: MathProblemType = "mixed"
): MathProblem[] {
  return Array.from({ length: count }, () => generateProblem(difficulty, type));
}
