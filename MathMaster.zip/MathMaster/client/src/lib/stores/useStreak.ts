import { create } from "zustand";
import { persist } from "zustand/middleware";
import { format, addDays, isToday } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

interface StreakState {
  streakData: {
    currentStreak: number;
    bestStreak: number;
    lastCompletedDate: string | null;
    daysCompleted: string[]; // ISO format dates
  };
  
  completeDaily: () => void;
  fetchStreakData: () => Promise<void>;
  resetStreak: () => void;
}

export const useStreak = create<StreakState>()(
  persist(
    (set, get) => ({
      streakData: {
        currentStreak: 0,
        bestStreak: 0,
        lastCompletedDate: null,
        daysCompleted: []
      },

      completeDaily: () => {
        const { streakData } = get();
        const today = format(new Date(), "yyyy-MM-dd");
        
        // If already completed today, do nothing
        if (streakData.lastCompletedDate === today) {
          return;
        }
        
        // Check if this continues a streak (yesterday was completed)
        const yesterday = format(addDays(new Date(), -1), "yyyy-MM-dd");
        const isStreakContinuation = streakData.lastCompletedDate === yesterday;
        
        const newCurrentStreak = isStreakContinuation 
          ? streakData.currentStreak + 1 
          : 1;
        
        const newBestStreak = Math.max(newCurrentStreak, streakData.bestStreak);
        
        // Add today to completed days
        const newDaysCompleted = [
          ...streakData.daysCompleted.filter(date => date !== today), 
          today
        ];
        
        set({
          streakData: {
            currentStreak: newCurrentStreak,
            bestStreak: newBestStreak,
            lastCompletedDate: today,
            daysCompleted: newDaysCompleted
          }
        });
        
        // Update server in background
        apiRequest("POST", "/api/streak/update", { 
          date: today,
          currentStreak: newCurrentStreak,
          bestStreak: newBestStreak
        });
      },

      fetchStreakData: async () => {
        try {
          const res = await apiRequest("GET", "/api/streak", undefined);
          const data = await res.json();
          set({ streakData: data });
        } catch (error) {
          console.error("Failed to fetch streak data", error);
        }
      },

      resetStreak: () => {
        set({
          streakData: {
            currentStreak: 0,
            bestStreak: 0,
            lastCompletedDate: null,
            daysCompleted: []
          }
        });
        
        // Update server in background
        apiRequest("POST", "/api/streak/reset", {});
      }
    }),
    {
      name: "streak-data",
      partialize: (state) => ({ streakData: state.streakData }),
    }
  )
);
