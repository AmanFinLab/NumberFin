import { create } from "zustand";
import { persist } from "zustand/middleware";
import { useStats } from "./useStats";

export type GameState = "ready" | "playing" | "ended";

interface MathDuelState {
  gameState: GameState;
  score: number;
  timeLeft: number;
  answeredCount: number;
  correctCount: number;
  startTime: number | null;
  timerInterval: number | null;
  
  startGame: () => void;
  endGame: () => void;
  answerProblem: (correct: boolean, timerTick?: boolean) => void;
  resetGame: () => void;
}

export const GAME_DURATION = 60; // seconds
export const COUNTDOWN_INTERVAL = 1000; // milliseconds

export const useMathDuel = create<MathDuelState>()(
  persist(
    (set, get) => ({
      gameState: "ready",
      score: 0,
      timeLeft: GAME_DURATION,
      answeredCount: 0,
      correctCount: 0,
      startTime: null,
      timerInterval: null,
      
      startGame: () => {
        // Clear any existing timer to avoid duplicates
        const currentTimer = get().timerInterval;
        if (currentTimer !== null) {
          clearInterval(currentTimer);
        }
        
        // Reset game state and start a new game
        set({
          gameState: "playing",
          score: 0,
          timeLeft: GAME_DURATION,
          answeredCount: 0,
          correctCount: 0,
          startTime: Date.now(),
          timerInterval: null
        });
        
        // Start the countdown timer
        const timer = window.setInterval(() => {
          set(state => {
            // Skip if game is no longer playing
            if (state.gameState !== "playing") {
              clearInterval(timer);
              return {};
            }
            
            const newTimeLeft = state.timeLeft - 1;
            
            if (newTimeLeft <= 0) {
              clearInterval(timer);
              // Call endGame to update stats
              get().endGame();
              return { timeLeft: 0, timerInterval: null };
            }
            
            return { timeLeft: newTimeLeft };
          });
        }, 1000);
        
        // Store the timer ID
        set({ timerInterval: timer });
        
        // Track game start in stats
        useStats.getState().incrementGamesPlayed();
      },
      
      endGame: () => {
        const { score, correctCount, answeredCount, startTime, timerInterval } = get();
        
        // Clean up the timer
        if (timerInterval !== null) {
          clearInterval(timerInterval);
        }
        
        set({ 
          gameState: "ended",
          timerInterval: null
        });
        
        // Calculate game stats
        if (startTime && answeredCount > 0) {
          const gameTime = (Date.now() - startTime) / 1000; // Convert to seconds
          const averageTime = Math.max(0.1, gameTime / answeredCount);
          
          // Update user stats
          try {
            useStats.getState().addResult(
              correctCount > 0, 
              averageTime,
              score
            );
          } catch (err) {
            console.error("Failed to update stats:", err);
          }
        }
      },
      
      answerProblem: (correct: boolean, timerTick: boolean = false) => {
        if (timerTick) {
          // Just update the timer without changing anything else
          set(state => ({
            timeLeft: Math.max(0, state.timeLeft - 1)
          }));
          return;
        }
        
        // Normal answer processing
        set(state => {
          // Increment counters
          const newAnsweredCount = state.answeredCount + 1;
          const newCorrectCount = correct ? state.correctCount + 1 : state.correctCount;
          
          // Add to score if correct
          const newScore = correct ? state.score + 1 : state.score;
          
          return {
            answeredCount: newAnsweredCount,
            correctCount: newCorrectCount,
            score: newScore
          };
        });
      },
      
      resetGame: () => {
        // Clear any existing timer
        const currentTimer = get().timerInterval;
        if (currentTimer !== null) {
          clearInterval(currentTimer);
        }
        
        set({
          gameState: "ready",
          score: 0,
          timeLeft: GAME_DURATION,
          answeredCount: 0,
          correctCount: 0,
          startTime: null,
          timerInterval: null
        });
      }
    }),
    {
      name: "math-duel-state",
      partialize: (state) => ({ 
        score: state.score, 
        correctCount: state.correctCount,
        answeredCount: state.answeredCount
      }),
    }
  )
);
