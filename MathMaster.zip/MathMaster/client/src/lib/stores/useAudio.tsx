import { create } from "zustand";

interface AudioState {
  backgroundMusic: HTMLAudioElement | null;
  hitSound: HTMLAudioElement | null;
  successSound: HTMLAudioElement | null;
  clickSound: HTMLAudioElement | null;
  countdownSound: HTMLAudioElement | null;
  gameOverSound: HTMLAudioElement | null;
  opponentMoveSound: HTMLAudioElement | null;
  isMuted: boolean;
  
  // Setter functions
  setBackgroundMusic: (music: HTMLAudioElement) => void;
  setHitSound: (sound: HTMLAudioElement) => void;
  setSuccessSound: (sound: HTMLAudioElement) => void;
  setClickSound: (sound: HTMLAudioElement) => void;
  setCountdownSound: (sound: HTMLAudioElement) => void;
  setGameOverSound: (sound: HTMLAudioElement) => void;
  setOpponentMoveSound: (sound: HTMLAudioElement) => void;
  
  // Control functions
  toggleMute: () => void;
  playHit: () => void;
  playSuccess: () => void;
  playClick: () => void;
  playCountdown: () => void;
  playGameOver: () => void;
  playOpponentMove: () => void;
  
  // Initialize sounds
  initSounds: () => void;
}

export const useAudio = create<AudioState>((set, get) => ({
  backgroundMusic: null,
  hitSound: null,
  successSound: null,
  clickSound: null,
  countdownSound: null,
  gameOverSound: null,
  opponentMoveSound: null,
  isMuted: false, // Start unmuted by default for better user experience
  
  setBackgroundMusic: (music) => set({ backgroundMusic: music }),
  setHitSound: (sound) => set({ hitSound: sound }),
  setSuccessSound: (sound) => set({ successSound: sound }),
  setClickSound: (sound) => set({ clickSound: sound }),
  setCountdownSound: (sound) => set({ countdownSound: sound }),
  setGameOverSound: (sound) => set({ gameOverSound: sound }),
  setOpponentMoveSound: (sound) => set({ opponentMoveSound: sound }),
  
  // Initialize all sounds at once
  initSounds: () => {
    // Background music
    const bgMusic = new Audio('/sounds/background-music.mp3');
    bgMusic.loop = true;
    bgMusic.volume = 0.2;
    
    // Sound effects
    const hitSound = new Audio('/sounds/hit.mp3');
    const successSound = new Audio('/sounds/success.mp3');
    const clickSound = new Audio('/sounds/click.mp3');
    const countdownSound = new Audio('/sounds/countdown.mp3');
    const gameOverSound = new Audio('/sounds/game-over.mp3');
    const opponentMoveSound = new Audio('/sounds/opponent-move.mp3');
    
    // Set all sounds in state
    set({
      backgroundMusic: bgMusic,
      hitSound: hitSound,
      successSound: successSound,
      clickSound: clickSound,
      countdownSound: countdownSound,
      gameOverSound: gameOverSound,
      opponentMoveSound: opponentMoveSound
    });
    
    // Start background music (will only play once user interacts with the page)
    bgMusic.play().catch(err => {
      console.log("Couldn't autoplay background music: ", err);
    });
  },
  
  toggleMute: () => {
    const { isMuted, backgroundMusic } = get();
    const newMutedState = !isMuted;
    
    // Update the muted state
    set({ isMuted: newMutedState });
    
    // Handle background music based on mute state
    if (backgroundMusic) {
      if (newMutedState) {
        backgroundMusic.pause();
      } else {
        backgroundMusic.play().catch(err => {
          console.log("Couldn't play background music: ", err);
        });
      }
    }
    
    // Log the change
    console.log(`Sound ${newMutedState ? 'muted' : 'unmuted'}`);
  },
  
  playHit: () => {
    const { hitSound, isMuted } = get();
    if (hitSound && !isMuted) {
      // Clone the sound to allow overlapping playback
      const soundClone = hitSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = 0.3;
      soundClone.play().catch(error => {
        console.log("Hit sound play prevented:", error);
      });
    }
  },
  
  playSuccess: () => {
    const { successSound, isMuted } = get();
    if (successSound && !isMuted) {
      successSound.currentTime = 0;
      successSound.volume = 0.4;
      successSound.play().catch(error => {
        console.log("Success sound play prevented:", error);
      });
    }
  },
  
  playClick: () => {
    const { clickSound, isMuted } = get();
    if (clickSound && !isMuted) {
      clickSound.currentTime = 0;
      clickSound.volume = 0.2;
      clickSound.play().catch(error => {
        console.log("Click sound play prevented:", error);
      });
    }
  },
  
  playCountdown: () => {
    const { countdownSound, isMuted } = get();
    if (countdownSound && !isMuted) {
      countdownSound.currentTime = 0;
      countdownSound.volume = 0.5;
      countdownSound.play().catch(error => {
        console.log("Countdown sound play prevented:", error);
      });
    }
  },
  
  playGameOver: () => {
    const { gameOverSound, isMuted } = get();
    if (gameOverSound && !isMuted) {
      gameOverSound.currentTime = 0;
      gameOverSound.volume = 0.5;
      gameOverSound.play().catch(error => {
        console.log("Game over sound play prevented:", error);
      });
    }
  },
  
  playOpponentMove: () => {
    const { opponentMoveSound, isMuted } = get();
    if (opponentMoveSound && !isMuted) {
      opponentMoveSound.currentTime = 0;
      opponentMoveSound.volume = 0.3;
      opponentMoveSound.play().catch(error => {
        console.log("Opponent move sound play prevented:", error);
      });
    }
  }
}));
