import { create } from 'zustand';
import { WebSocketMessage, WebSocketMessageType } from '@shared/types';

interface WebSocketState {
  // Connection state
  isConnected: boolean;
  isConnecting: boolean;
  connectionError: string | null;
  
  // Session data
  sessionId: string | null;
  
  // Game state for duel
  opponent: string | null;
  waitingForOpponent: boolean;
  gameInProgress: boolean;
  
  // Methods
  connect: () => void;
  disconnect: () => void;
  joinDuel: () => void;
  submitAnswer: (answer: string, score: number) => void;
  
  // Mock responses (for development without WebSocket)
  sendMockResponse: (type: WebSocketMessageType, data?: any) => void;
}

export const useWebSocketStore = create<WebSocketState>((set, get) => {
  // Use a simulated connection in the Replit environment
  // to avoid conflicts with Vite's WebSocket server
  
  return {
    // State
    isConnected: false,
    isConnecting: false,
    connectionError: null,
    sessionId: null,
    opponent: null,
    waitingForOpponent: false,
    gameInProgress: false,
    
    // Connect to WebSocket server
    connect: () => {
      set({ isConnecting: true, connectionError: null });
      
      // Simulate connection success
      setTimeout(() => {
        console.log("[WebSocket] Connected (simulated)");
        set({ 
          isConnected: true, 
          isConnecting: false,
          sessionId: 'sim-' + Math.random().toString(36).substring(2, 9)
        });
      }, 500);
    },
    
    // Disconnect from WebSocket server
    disconnect: () => {
      console.log("[WebSocket] Disconnected (simulated)");
      set({ 
        isConnected: false, 
        isConnecting: false,
        sessionId: null,
        opponent: null,
        waitingForOpponent: false,
        gameInProgress: false
      });
    },
    
    // Join a duel match
    joinDuel: () => {
      const { isConnected } = get();
      
      if (!isConnected) {
        console.error("[WebSocket] Cannot join duel: Not connected");
        return;
      }
      
      console.log("[WebSocket] Join duel requested (simulated)");
      set({ waitingForOpponent: true });
      
      // Simulate finding an opponent with a random username
      setTimeout(() => {
        // List of realistic usernames to make the game feel more populated
        const usernames = [
          'MathGenius', 'NumberWiz', 'AlgebraKing', 'QuickSolver', 'MathMaster',
          'StatNinja', 'NumLord', 'PiWizard', 'CalcQueen', 'MathHero',
          'NumberGuru', 'LogicPro', 'MathWhiz', 'EinsteinJr', 'PyThagoras',
          'DigitMaster', 'MathZilla', 'FractionFan', 'DecimalDiva', 'EqMaster'
        ];
        
        // Generate a random username with suffix
        const randomUsername = usernames[Math.floor(Math.random() * usernames.length)] + 
                               Math.floor(Math.random() * 1000);
                               
        get().sendMockResponse('duel_status', {
          status: 'opponent_found',
          opponent: {
            username: randomUsername,
            score: 0
          }
        });
      }, 2000);
    },
    
    // Submit an answer to the current problem
    submitAnswer: (answer: string, score: number) => {
      const { isConnected, gameInProgress } = get();
      
      if (!isConnected || !gameInProgress) {
        console.error("[WebSocket] Cannot submit answer: Not in game");
        return;
      }
      
      console.log(`[WebSocket] Submit answer: ${answer}, score: ${score} (simulated)`);
      
      const isCorrect = Math.random() > 0.3; // Player has 70% chance of being correct
      
      // Simulate answer result
      setTimeout(() => {
        get().sendMockResponse('answer_result', {
          correct: isCorrect,
          score
        });
        
        // Simulate computer bot answering after player's turn (only if game in progress)
        if (get().gameInProgress) {
          // Computer has a slightly lower accuracy (60%) to give player advantage
          const computerCorrect = Math.random() > 0.4;
          
          // Add to the computer's score if correct
          if (computerCorrect) {
            // Use current score to simulate opponent's increasing score
            const currentOpponentScore = Math.floor(score / 10) * 10;
            
            // Simulate the opponent answering correctly 
            setTimeout(() => {
              get().sendMockResponse('game_update', {
                type: 'opponent_answer',
                result: {
                  correct: computerCorrect,
                  opponentScore: currentOpponentScore + 10
                }
              });
            }, 800 + Math.random() * 1200); // Random delay between 0.8-2s
          }
        }
      }, 300);
    },
    
    // Process a mock response (for development without WebSocket)
    sendMockResponse: (type: WebSocketMessageType, data: any = {}) => {
      console.log(`[WebSocket] Mock response: ${type}`, data);
      
      // Process different message types
      switch (type) {
        case 'duel_status':
          if (data.status === 'waiting_for_opponent') {
            set({ waitingForOpponent: true, gameInProgress: false });
          } else if (data.status === 'opponent_found') {
            set({ 
              waitingForOpponent: false, 
              gameInProgress: true,
              opponent: data.opponent.username
            });
          }
          break;
          
        case 'answer_result':
          // Handle answer result
          console.log(`[WebSocket] Answer result: ${data.correct ? 'correct' : 'incorrect'}`);
          // Dispatch custom event for answer result
          window.dispatchEvent(new CustomEvent('ws_answer_result', { 
            detail: data 
          }));
          break;
        
        case 'game_update':
          // Handle game updates (like opponent moves)
          console.log(`[WebSocket] Game update: ${data.type}`);
          
          // You can add custom handling for different types of updates here
          if (data.type === 'opponent_answer') {
            console.log(`[WebSocket] Opponent answer: ${data.result.correct ? 'correct' : 'incorrect'}, score: ${data.result.opponentScore}`);
          }
          
          // Dispatch custom event for game updates
          window.dispatchEvent(new CustomEvent('ws_game_update', { 
            detail: data 
          }));
          break;
          
        case 'game_end':
          set({ 
            gameInProgress: false,
            waitingForOpponent: false,
            opponent: null
          });
          // Dispatch custom event for game end
          window.dispatchEvent(new CustomEvent('ws_game_end', { 
            detail: data 
          }));
          break;
          
        default:
          console.log(`[WebSocket] Unhandled mock message type: ${type}`);
      }
    }
  };
});