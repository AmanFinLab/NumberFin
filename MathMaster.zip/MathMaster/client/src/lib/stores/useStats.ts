import { create } from "zustand";
import { persist } from "zustand/middleware";
import { apiRequest } from "@/lib/queryClient";

interface UserStats {
  gamesPlayed: number;
  correctAnswers: number;
  incorrectAnswers: number;
  averageTime: number;
  highScore: number;
  lastPlayed: string;
}

interface StatsState {
  stats: UserStats;
  isLoading: boolean;
  error: string | null;
  
  fetchStats: () => Promise<void>;
  incrementGamesPlayed: () => void;
  addResult: (correct: boolean, time: number, score: number) => void;
  resetStats: () => void;
}

const initialStats: UserStats = {
  gamesPlayed: 0,
  correctAnswers: 0,
  incorrectAnswers: 0,
  averageTime: 0,
  highScore: 0,
  lastPlayed: new Date().toISOString()
};

export const useStats = create<StatsState>()(
  persist(
    (set, get) => ({
      stats: initialStats,
      isLoading: false,
      error: null,

      fetchStats: async () => {
        set({ isLoading: true });
        try {
          const res = await apiRequest("GET", "/api/stats", undefined);
          const data = await res.json();
          set({ stats: data, isLoading: false });
        } catch (error) {
          set({ 
            error: error instanceof Error ? error.message : "Failed to fetch stats", 
            isLoading: false 
          });
        }
      },

      incrementGamesPlayed: () => {
        set((state) => ({
          stats: {
            ...state.stats,
            gamesPlayed: state.stats.gamesPlayed + 1,
            lastPlayed: new Date().toISOString()
          }
        }));
        
        // Update server in background
        apiRequest("POST", "/api/stats/increment-game", {});
      },

      addResult: (correct: boolean, time: number, score: number) => {
        set((state) => {
          const { stats } = state;
          const totalAnswers = stats.correctAnswers + stats.incorrectAnswers;
          const newCorrect = correct ? stats.correctAnswers + 1 : stats.correctAnswers;
          const newIncorrect = !correct ? stats.incorrectAnswers + 1 : stats.incorrectAnswers;
          
          // Calculate new average time
          const newTotalTime = stats.averageTime * totalAnswers + time;
          const newAverageTime = newTotalTime / (totalAnswers + 1);
          
          // Determine new high score
          const newHighScore = score > stats.highScore ? score : stats.highScore;
          
          return {
            stats: {
              ...stats,
              correctAnswers: newCorrect,
              incorrectAnswers: newIncorrect,
              averageTime: newAverageTime,
              highScore: newHighScore,
              lastPlayed: new Date().toISOString()
            }
          };
        });
        
        // Update server in background
        apiRequest("POST", "/api/stats/add-result", { correct, time, score });
      },

      resetStats: () => {
        set({ stats: initialStats });
        
        // Update server in background
        apiRequest("POST", "/api/stats/reset", {});
      }
    }),
    {
      name: "user-stats",
      partialize: (state) => ({ stats: state.stats }),
    }
  )
);
