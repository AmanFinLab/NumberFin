import { NavLink } from "react-router-dom";
import { 
  BookOpen, Brain, ChevronRight, FlameIcon, Home, 
  GraduationCap, BookOpenText, LogIn, LogOut, Medal, Trophy, User, UserPlus 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useIsMobile } from "@/hooks/use-is-mobile";
import { useAuth } from "@/lib/stores/useAuth";

export default function Sidebar() {
  const [expanded, setExpanded] = useState(false);
  const isMobile = useIsMobile();
  const { isAuthenticated, user, logout } = useAuth();
  
  // If mobile, sidebar is collapsible
  const sidebarWidth = isMobile ? (expanded ? "w-[200px]" : "w-[60px]") : "w-[200px]";
  
  const toggleSidebar = () => {
    setExpanded(!expanded);
  };

  // Sidebar nav links for authenticated users
  const authenticatedItems = [
    { path: "/", label: "Arena", icon: <Home className="h-5 w-5" /> },
    { path: "/daily-challenge", label: "Daily Challenge", icon: <FlameIcon className="h-5 w-5" /> },
    { path: "/learn", label: "Math Tricks", icon: <GraduationCap className="h-5 w-5" /> },
    { path: "/leaderboard", label: "Leaderboard", icon: <Trophy className="h-5 w-5" /> },
    { path: "/profile", label: "My Profile", icon: <User className="h-5 w-5" /> },
  ];
  
  // Sidebar nav links for guests (not authenticated)
  const guestItems = [
    { path: "/", label: "Arena", icon: <Home className="h-5 w-5" /> },
    { path: "/learn", label: "Math Tricks", icon: <GraduationCap className="h-5 w-5" /> },
    { path: "/leaderboard", label: "Leaderboard", icon: <Trophy className="h-5 w-5" /> },
    { path: "/login", label: "Sign In", icon: <LogIn className="h-5 w-5" /> },
    { path: "/register", label: "Sign Up", icon: <UserPlus className="h-5 w-5" /> },
  ];
  
  // Use appropriate nav items based on authentication status
  const navItems = isAuthenticated ? authenticatedItems : guestItems;

  return (
    <aside 
      className={cn(
        "fixed left-0 top-0 h-full bg-[#171717] text-white transition-all duration-300 ease-in-out z-50 border-r border-gray-800",
        sidebarWidth
      )}
    >
      {isMobile && (
        <button
          onClick={toggleSidebar}
          className="absolute -right-3 top-10 flex h-6 w-6 items-center justify-center rounded-full bg-green-500 text-white"
        >
          <ChevronRight className={cn("h-4 w-4 transition-transform", expanded ? "rotate-180" : "")} />
        </button>
      )}

      <div className="mt-6 flex flex-col h-full">
        <div className="flex items-center justify-center mb-8">
          <Brain className="h-8 w-8 text-blue-500" />
          {(!isMobile || expanded) && <span className="ml-2 text-xl font-bold">NumberFin</span>}
        </div>
        
        <nav className="mt-8 flex-grow">
          <ul className="space-y-2 px-3">
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center rounded-md px-3 py-2 transition-colors",
                      isActive
                        ? "bg-blue-500/20 text-blue-500"
                        : "hover:bg-gray-800 text-gray-400"
                    )
                  }
                >
                  <span className="mr-3">{item.icon}</span>
                  {(!isMobile || expanded) && <span>{item.label}</span>}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Logout button for authenticated users */}
        {isAuthenticated && (
          <div className="px-3 mb-8">
            <button
              onClick={() => logout()}
              className="flex w-full items-center rounded-md px-3 py-2 transition-colors hover:bg-gray-800 text-gray-400"
            >
              <span className="mr-3"><LogOut className="h-5 w-5" /></span>
              {(!isMobile || expanded) && <span>Logout</span>}
            </button>
          </div>
        )}
      </div>
    </aside>
  );
}
