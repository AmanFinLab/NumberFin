import { cn } from "@/lib/utils";
import { FlameIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import WeekCalendar from "./WeekCalendar";

interface StreakDisplayProps {
  currentStreak: number;
  bestStreak: number;
  daysCompleted: string[];
  className?: string;
}

export default function StreakDisplay({ 
  currentStreak, 
  bestStreak, 
  daysCompleted, 
  className 
}: StreakDisplayProps) {
  return (
    <Card className={cn("overflow-hidden dark:bg-[#222] border-0", className)}>
      <CardContent className="p-0">
        <div className="bg-gradient-to-r from-orange-500 to-red-500 p-4 flex items-center">
          <div className="mr-3">
            <FlameIcon size={36} className="text-white" />
          </div>
          <div>
            <h3 className="text-white font-bold text-lg">{currentStreak} Day Streak</h3>
            <p className="text-white/80 text-sm">{bestStreak} Best Streak</p>
          </div>
        </div>
        
        <div className="p-4">
          <WeekCalendar daysCompleted={daysCompleted} />
        </div>
      </CardContent>
    </Card>
  );
}
