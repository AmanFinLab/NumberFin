import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface WeekCalendarProps {
  daysCompleted: string[]; // ISO date strings of completed days
}

export default function WeekCalendar({ daysCompleted }: WeekCalendarProps) {
  // Generate weekday labels and dates for the current week
  const today = new Date();
  const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
  
  const weekdays = [
    { short: "S", long: "Sunday" },
    { short: "M", long: "Monday" },
    { short: "T", long: "Tuesday" },
    { short: "W", long: "Wednesday" },
    { short: "T", long: "Thursday" },
    { short: "F", long: "Friday" },
    { short: "S", long: "Saturday" },
  ];
  
  // Create array of dates for the week
  const week = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(today);
    date.setDate(today.getDate() - dayOfWeek + i);
    return {
      date,
      isoDate: format(date, "yyyy-MM-dd"),
      isToday: i === dayOfWeek,
      isCompleted: daysCompleted.includes(format(date, "yyyy-MM-dd")),
      isPast: date < today && !date.setHours(0,0,0,0) === today.setHours(0,0,0,0)
    };
  });
  
  return (
    <div className="grid grid-cols-7 gap-1 text-center">
      {weekdays.map((day, index) => (
        <div key={`label-${index}`} className="text-xs font-medium text-gray-400">
          {day.short}
        </div>
      ))}
      
      {week.map((day, index) => (
        <div key={`day-${index}`} className="mt-1">
          <div 
            className={cn(
              "size-8 mx-auto rounded-md flex items-center justify-center text-sm",
              day.isToday && "border border-green-500",
              day.isCompleted ? "bg-green-500 text-white" : "bg-gray-800/50",
              !day.isCompleted && day.isPast ? "opacity-50" : "opacity-100"
            )}
          >
            {day.date.getDate()}
          </div>
        </div>
      ))}
    </div>
  );
}
