import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Medal, Clock, Zap, Brain } from "lucide-react";

interface UserStatsProps {
  username: string;
  gamesPlayed: number;
  highestStreak: number;
  averageSpeed: number;
  correctAnswers: number;
  totalQuestions: number;
}

export default function UserStats({
  username,
  gamesPlayed,
  highestStreak,
  averageSpeed,
  correctAnswers,
  totalQuestions
}: UserStatsProps) {
  // Calculate accuracy percentage
  const accuracy = totalQuestions > 0 
    ? Math.round((correctAnswers / totalQuestions) * 100) 
    : 0;
  
  const statItems = [
    {
      name: "Games Played",
      value: gamesPlayed,
      icon: <Medal className="h-5 w-5 text-yellow-500" />
    },
    {
      name: "Best Streak",
      value: highestStreak,
      icon: <Zap className="h-5 w-5 text-orange-500" />
    },
    {
      name: "Avg. Answer Time",
      value: `${averageSpeed.toFixed(1)}s`,
      icon: <Clock className="h-5 w-5 text-blue-500" />
    },
    {
      name: "Accuracy",
      value: `${accuracy}%`,
      icon: <Brain className="h-5 w-5 text-green-500" />
    }
  ];
  
  return (
    <Card className="border-0 bg-gray-900">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold">{username}'s Stats</CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {statItems.map((stat, index) => (
            <div 
              key={index} 
              className="flex items-center space-x-3 bg-gray-800 p-3 rounded-lg"
            >
              <div className="size-10 flex items-center justify-center rounded-full bg-gray-700">
                {stat.icon}
              </div>
              <div>
                <p className="text-sm text-gray-400">{stat.name}</p>
                <p className="text-lg font-bold">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
