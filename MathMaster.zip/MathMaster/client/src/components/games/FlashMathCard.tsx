import React from "react";
import { Button } from "@/components/ui/button";
import { Calculator } from "lucide-react";

interface FlashMathCardProps {
  title: string;
  subtitle: string;
  onPlay: () => void;
}

export default function FlashMathCard({ title, subtitle, onPlay }: FlashMathCardProps) {
  return (
    <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-xl p-6 text-white h-full flex flex-col">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          <p className="text-orange-100 text-sm leading-relaxed">{subtitle}</p>
        </div>
        <div className="bg-orange-600/50 p-2 rounded-lg">
          <Calculator className="w-7 h-7" />
        </div>
      </div>
      
      <div className="mt-auto">
        <div className="mb-4 grid grid-cols-2 gap-2">
          <div className="bg-orange-900/30 px-3 py-2 rounded-lg text-center">
            <p className="text-xs text-orange-200 mb-1">Time Limit</p>
            <p className="font-semibold">60 seconds</p>
          </div>
          <div className="bg-orange-900/30 px-3 py-2 rounded-lg text-center">
            <p className="text-xs text-orange-200 mb-1">Problem Types</p>
            <p className="font-semibold">All Operations</p>
          </div>
        </div>
        
        <Button 
          onClick={onPlay}
          className="w-full bg-white text-orange-600 hover:bg-orange-100 font-semibold"
        >
          Play Now
        </Button>
      </div>
    </div>
  );
}