import React, { ReactNode } from "react";

interface GameCardProps {
  title: string;
  subtitle: string;
  icon: ReactNode;
  colorScheme: "orange" | "blue" | "purple" | "green";
  onClick?: () => void;
  className?: string;
  mostPlayed?: boolean;
}

export default function GameCard({ 
  title, 
  subtitle, 
  icon, 
  colorScheme, 
  onClick,
  className = "",
  mostPlayed 
}: GameCardProps) {
  // Determine gradient based on colorScheme
  const getGradient = () => {
    switch (colorScheme) {
      case "orange": return "from-orange-500 to-red-600";
      case "blue": return "from-blue-500 to-indigo-600";
      case "purple": return "from-purple-500 to-violet-600";
      case "green": return "from-green-500 to-emerald-600";
      default: return "from-blue-500 to-indigo-600";
    }
  };
  
  const gradient = getGradient();
  
  return (
    <div 
      className={`bg-gradient-to-br ${gradient} rounded-xl p-6 text-white h-full flex flex-col relative ${className} ${onClick ? 'cursor-pointer transition-transform hover:scale-[1.02]' : ''}`}
      onClick={onClick}
    >
      {mostPlayed && (
        <div className="absolute -top-3 -right-2 bg-yellow-500 text-black text-xs font-bold px-3 py-1 rounded-full shadow-lg">
          POPULAR
        </div>
      )}
      
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          <p className="text-opacity-90 text-white text-sm leading-relaxed">{subtitle}</p>
        </div>
        <div className="bg-white/20 p-2 rounded-lg">
          {icon}
        </div>
      </div>
      
      <div className="mt-auto pt-4">
        <div className="inline-flex items-center text-sm font-medium">
          {onClick && (
            <>
              <span>Start Challenge</span>
              <svg 
                className="ml-2 w-4 h-4" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M14 5l7 7m0 0l-7 7m7-7H3" 
                />
              </svg>
            </>
          )}
        </div>
      </div>
    </div>
  );
}