import { format } from "date-fns";
import { ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface DailyPuzzlePreviewProps {
  puzzleType: string;
  puzzleId: string;
  date: Date;
  onClick: () => void;
  className?: string;
}

export default function DailyPuzzlePreview({
  puzzleType,
  puzzleId,
  date,
  onClick,
  className
}: DailyPuzzlePreviewProps) {
  // Get puzzle icon based on type
  const getPuzzleIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "cross math":
        return (
          <div className="grid grid-cols-3 gap-1 size-8">
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
            <div className="bg-white/80 size-2"></div>
          </div>
        );
      case "div3":
        return (
          <div className="text-white font-mono font-bold text-xl">
            ÷3
          </div>
        );
      case "open":
      default:
        return (
          <div className="size-8 border-2 border-white/80 flex items-center justify-center rounded-md">
            <div className="size-5 bg-white/80 rounded-sm"></div>
          </div>
        );
    }
  };

  return (
    <Card 
      className={cn(
        "cursor-pointer hover:bg-gray-800/50 transition-colors",
        className
      )}
      onClick={onClick}
    >
      <CardContent className="p-4 flex items-center">
        <div className="mr-4 flex-shrink-0">
          {getPuzzleIcon(puzzleType)}
        </div>
        
        <div className="flex-1">
          <h3 className="text-base font-semibold text-white">{puzzleType}</h3>
          <p className="text-sm text-gray-400">
            {format(date, "EEEE, MMM dd")}
          </p>
        </div>
        
        <div>
          <ChevronRight className="text-gray-400 h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  );
}
