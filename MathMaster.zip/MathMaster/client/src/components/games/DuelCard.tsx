import React from "react";
import { Button } from "@/components/ui/button";
import { Swords } from "lucide-react";

interface DuelCardProps {
  title: string;
  subtitle: string;
  colorScheme: "orange" | "blue" | "purple" | "green";
  onPlay: () => void;
  mostPlayed?: boolean;
}

export default function DuelCard({ 
  title, 
  subtitle, 
  colorScheme, 
  onPlay,
  mostPlayed 
}: DuelCardProps) {
  // Determine color classes based on the color scheme
  const getColorClasses = () => {
    switch (colorScheme) {
      case "orange":
        return {
          bg: "from-orange-500 to-red-600",
          accent: "bg-orange-600/50",
          text: "text-orange-100",
          detail: "bg-orange-900/30",
          detailText: "text-orange-200",
          button: "text-orange-600 hover:bg-orange-100"
        };
      case "blue":
        return {
          bg: "from-blue-500 to-indigo-600",
          accent: "bg-blue-600/50",
          text: "text-blue-100",
          detail: "bg-blue-900/30",
          detailText: "text-blue-200",
          button: "text-blue-600 hover:bg-blue-100"
        };
      case "purple":
        return {
          bg: "from-purple-500 to-violet-600",
          accent: "bg-purple-600/50",
          text: "text-purple-100",
          detail: "bg-purple-900/30",
          detailText: "text-purple-200",
          button: "text-purple-600 hover:bg-purple-100"
        };
      case "green":
        return {
          bg: "from-green-500 to-emerald-600",
          accent: "bg-green-600/50",
          text: "text-green-100",
          detail: "bg-green-900/30",
          detailText: "text-green-200",
          button: "text-green-600 hover:bg-green-100"
        };
      default:
        return {
          bg: "from-blue-500 to-indigo-600",
          accent: "bg-blue-600/50",
          text: "text-blue-100",
          detail: "bg-blue-900/30",
          detailText: "text-blue-200",
          button: "text-blue-600 hover:bg-blue-100"
        };
    }
  };
  
  const colors = getColorClasses();
  
  return (
    <div className={`bg-gradient-to-br ${colors.bg} rounded-xl p-6 text-white h-full flex flex-col relative`}>
      {mostPlayed && (
        <div className="absolute -top-3 -right-2 bg-yellow-500 text-black text-xs font-bold px-3 py-1 rounded-full shadow-lg">
          POPULAR
        </div>
      )}
      
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          <p className={`${colors.text} text-sm leading-relaxed`}>{subtitle}</p>
        </div>
        <div className={`${colors.accent} p-2 rounded-lg`}>
          <Swords className="w-7 h-7" />
        </div>
      </div>
      
      <div className="mt-auto">
        <div className="mb-4 grid grid-cols-2 gap-2">
          <div className={`${colors.detail} px-3 py-2 rounded-lg text-center`}>
            <p className={`text-xs ${colors.detailText} mb-1`}>Mode</p>
            <p className="font-semibold">1 vs 1</p>
          </div>
          <div className={`${colors.detail} px-3 py-2 rounded-lg text-center`}>
            <p className={`text-xs ${colors.detailText} mb-1`}>Rewards</p>
            <p className="font-semibold">Double Points</p>
          </div>
        </div>
        
        <Button 
          onClick={onPlay}
          className={`w-full bg-white ${colors.button} font-semibold`}
        >
          Find Opponent
        </Button>
      </div>
    </div>
  );
}