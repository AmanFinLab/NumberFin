import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import { useIsMobile } from "@/hooks/use-is-mobile";
import { cn } from "@/lib/utils";

export default function Layout() {
  const isMobile = useIsMobile();

  return (
    <div className="flex h-full min-h-screen bg-[#111111] text-white">
      <Sidebar />
      
      <main className={cn(
        "flex-1 overflow-auto p-4 transition-all duration-200 ease-in-out",
        isMobile ? "ml-0" : "ml-[200px]"
      )}>
        <Outlet />
      </main>
    </div>
  );
}
