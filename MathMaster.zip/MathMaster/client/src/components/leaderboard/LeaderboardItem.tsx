import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface LeaderboardItemProps {
  rank: number;
  username: string;
  score: number;
  avatarUrl?: string;
  isCurrentUser?: boolean;
}

export default function LeaderboardItem({
  rank,
  username,
  score,
  avatarUrl,
  isCurrentUser = false
}: LeaderboardItemProps) {
  // Get rank badge color
  const getRankColor = (rank: number) => {
    if (rank === 1) return "bg-yellow-500";
    if (rank === 2) return "bg-gray-400";
    if (rank === 3) return "bg-amber-700";
    return "bg-gray-700";
  };
  
  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    return name.slice(0, 2).toUpperCase();
  };
  
  return (
    <div 
      className={cn(
        "flex items-center justify-between p-3 rounded-lg",
        isCurrentUser ? "bg-green-500/20 border border-green-500/50" : "bg-gray-800/50"
      )}
    >
      <div className="flex items-center space-x-3">
        <div 
          className={cn(
            "size-8 flex items-center justify-center rounded-full text-white font-bold text-sm",
            getRankColor(rank)
          )}
        >
          {rank}
        </div>
        
        <Avatar className="size-9 border-2 border-gray-700">
          <AvatarImage src={avatarUrl} />
          <AvatarFallback className="bg-gray-700 text-gray-200">
            {getInitials(username)}
          </AvatarFallback>
        </Avatar>
        
        <span className={cn(
          "font-medium",
          isCurrentUser ? "text-green-400" : "text-white"
        )}>
          {username}
        </span>
      </div>
      
      <div className="text-lg font-bold">{score}</div>
    </div>
  );
}
