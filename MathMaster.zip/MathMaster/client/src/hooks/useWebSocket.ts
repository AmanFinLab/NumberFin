import { useEffect, useCallback, useState } from 'react';
import { getWebSocket, sendMessage, onMessage, closeConnection } from '../lib/websocket';

export type WebSocketStatus = 'connecting' | 'connected' | 'disconnected' | 'error';

export interface UseWebSocketOptions {
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
  autoConnect?: boolean;
}

export function useWebSocket(options: UseWebSocketOptions = {}) {
  const [status, setStatus] = useState<WebSocketStatus>('disconnected');
  
  const connect = useCallback(() => {
    if (status !== 'connected') {
      try {
        const socket = getWebSocket();
        
        socket.onopen = () => {
          setStatus('connected');
          if (options.onOpen) options.onOpen();
        };
        
        socket.onclose = () => {
          setStatus('disconnected');
          if (options.onClose) options.onClose();
        };
        
        socket.onerror = (error) => {
          setStatus('error');
          if (options.onError) options.onError(error);
        };
        
        setStatus('connecting');
      } catch (error) {
        console.error('Failed to connect to WebSocket:', error);
        setStatus('error');
      }
    }
  }, [status, options]);
  
  const disconnect = useCallback(() => {
    closeConnection();
    setStatus('disconnected');
  }, []);
  
  // Set up connection and cleanup
  useEffect(() => {
    if (options.autoConnect !== false) {
      connect();
    }
    
    return () => {
      disconnect();
    };
  }, [connect, disconnect, options.autoConnect]);
  
  // Create wrapped sendMessage function
  const send = useCallback((type: string, data: any = {}) => {
    sendMessage(type, data);
  }, []);
  
  // Create wrapped onMessage function 
  const listen = useCallback((type: string, handler: (data: any) => void) => {
    return onMessage(type, handler);
  }, []);
  
  return {
    status,
    connect,
    disconnect,
    send,
    listen
  };
}