import { useEffect, useState } from "react";
import { Routes, Route, Navigate, UNSAFE_RouteContext } from "react-router-dom";
import { 
  UNSAFE_DataRouterContext,
  UNSAFE_DataRouterStateContext 
} from "react-router-dom";

// Configure future flags
UNSAFE_RouteContext._FUTURE_FLAGS.v7_startTransition = true;
UNSAFE_DataRouterContext._FUTURE_FLAGS.v7_startTransition = true;
UNSAFE_DataRouterStateContext._FUTURE_FLAGS.v7_relativeSplatPath = true;
import { ThemeProvider } from "next-themes";
import { useAudio } from "./lib/stores/useAudio";
import Layout from "./components/Layout";
import HomePage from "./pages/HomePage";
import LeaderboardPage from "./pages/LeaderboardPage";
import ProfilePage from "./pages/ProfilePage";
import DuelPage from "./pages/DuelPage";
import FlashMathPage from "./pages/FlashMathPage";
import DailyChallengePage from "./pages/DailyChallengePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import NotFound from "./pages/not-found";
import LearnPage from "./pages/LearnPage";
import "@fontsource/inter";

function App() {
  const [mounted, setMounted] = useState(false);
  const { initSounds, playClick } = useAudio();

  // Load audio and setup global event handlers
  useEffect(() => {
    // Initialize all audio
    initSounds();
    
    // Add click sound to all button clicks
    const handleButtonClick = () => {
      playClick();
    };
    
    // Listen for clicks on buttons
    document.addEventListener('click', (e) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'BUTTON' || 
        target.closest('button') || 
        target.classList.contains('cursor-pointer')
      ) {
        handleButtonClick();
      }
    });
    
    setMounted(true);
    
    return () => {
      document.removeEventListener('click', handleButtonClick);
    };
  }, [initSounds, playClick]);

  if (!mounted) return null;

  return (
    <ThemeProvider attribute="class" defaultTheme="dark">
      <Routes>
        {/* Auth Routes outside the main layout */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* Main App Routes with Layout */}
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="leaderboard" element={<LeaderboardPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="duel" element={<DuelPage />} />
          <Route path="flash-math" element={<FlashMathPage />} />
          <Route path="daily-challenge" element={<DailyChallengePage />} />
          <Route path="learn" element={<LearnPage />} />
          <Route path="404" element={<NotFound />} />
          <Route path="*" element={<Navigate to="/404" replace />} />
        </Route>
      </Routes>
    </ThemeProvider>
  );
}

export default App;
